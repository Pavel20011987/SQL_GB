
CREATE DATABASE WorkTime_sk

USE WorkTime_sk



CREATE TABLE Posts
(
  KodPost INT NOT NULL IDENTITY(1,1),
  NamePost NVARCHAR(max) NOT NULL
  Constraint PK_Post PRIMARY KEY(KodPost)
)



CREATE TABLE Users
(
  KodUser INT NOT NULL IDENTITY(1,1),
  NameUser NVARCHAR(max) NOT NULL,
  Birth DATE NOT NULL,
  Telephone NVARCHAR(max) NULL,
  KodPost INT NOT NULL,
  RoomNumber INT NOT NULL,
  Password NVARCHAR(max) NOT NULL,
  Email NVARCHAR(max) NULL
  Constraint PK_User PRIMARY KEY(KodUser)
  Constraint FK_Post Foreign Key(KodPost) references Posts(KodPost)
 ON DELETE CASCADE ON UPDATE CASCADE
)



CREATE TABLE Tasks
(
  KodTask INT NOT NULL IDENTITY(1,1),
  KodUser INT NOT NULL,
  DateTask DATE NOT NULL,
  TextTask NVARCHAR(max) NOT NULL
  Constraint PK_Task PRIMARY KEY(KodTask)
  Constraint FK_User Foreign Key(KodUser) references Users(KodUser)
  ON DELETE CASCADE ON UPDATE CASCADE
)



CREATE TABLE Shedule
(
  KodRecord INT NOT NULL IDENTITY(1,1),
  Description NVARCHAR(max) NULL,
  DateRecord DATE NOT NULL,
  TimeBegin TIME(7) NOT NULL,
  TimeEnd TIME(7) NOT NULL,
  Result SMALLINT NOT NULL,
  KodUser INT NOT NULL
  Constraint PK_Record PRIMARY KEY(KodRecord)
  Constraint FK_Users Foreign Key(KodUser) references Users(KodUser)
  ON DELETE CASCADE ON UPDATE CASCADE
)



CREATE TABLE Remindings
(
  KodReminding INT NOT NULL IDENTITY(1,1),
  TextReminding NVARCHAR(max) NOT NULL,
  KodUser INT NOT NULL,
  DateReminding DATE NOT NULL
  Constraint PK_Reminding PRIMARY KEY(KodReminding)
  Constraint FK_Useros Foreign Key(KodUser) references Users(KodUser)
  ON DELETE CASCADE ON UPDATE CASCADE
)



CREATE TABLE MateriallyResponsiblePerson
(
  idMateriallyResponsiblePerson INT NOT NULL IDENTITY(1,1),
  Surname NVARCHAR(45) NOT NULL,
  Name NVARCHAR(45) NOT NULL,
  Patronimic NVARCHAR(45) NOT NULL
  Constraint PK_Mol PRIMARY KEY(idMateriallyResponsiblePerson)
)



CREATE TABLE FixedAssets
(
  idFixedAssets INT NOT NULL IDENTITY(1,1),
  DesignationFixedAssets NVARCHAR(45) NOT NULL,
  idMateriallyResponsiblePerson INT NOT NULL,
  Gold INT NOT NULL,
  Silver INT NOT NULL,
  Platinum INT NOT NULL,
  PlatiumGroupMetal INT NOT NULL
  Constraint PK_FixedAssets PRIMARY KEY(idFixedAssets)
  Constraint FK_MOL Foreign Key(idMateriallyResponsiblePerson) references MateriallyResponsiblePerson(idMateriallyResponsiblePerson)
  ON DELETE CASCADE ON UPDATE CASCADE
  
)



CREATE TABLE Inflows
(
  idInflows INT NOT NULL IDENTITY(1,1),
  idFixedAssets INT NOT NULL,
  DeliveryDate DATE NOT NULL,
  Quantity NVARCHAR(45) NOT NULL,
  Price NVARCHAR(45) NOT NULL
  Constraint PK_Inflows PRIMARY KEY(idInflows)
 Constraint FK_FixedAssetsI Foreign Key(idFixedAssets) references FixedAssets(idFixedAssets)
  ON DELETE CASCADE ON UPDATE CASCADE
)



CREATE TABLE Outlay
(
  idOutlay INT NOT NULL IDENTITY(1,1),
  idFixedAssets INT NOT NULL,
  CostToDate DATE NOT NULL,
  Quantity NVARCHAR(45) NOT NULL,
  Price NVARCHAR(45) NOT NULL
  Constraint PK_Outlay PRIMARY KEY(idOutlay)
 Constraint FK_FixedAssetsO Foreign Key(idFixedAssets) references FixedAssets(idFixedAssets)
 ON DELETE CASCADE ON UPDATE CASCADE
  
)

CREATE TABLE Balance
(
   idBalance INT NOT NULL IDENTITY(1,1),
   idFixedAssets INT NOT NULL,
   Quantity NVARCHAR(45) NOT NULL
   Constraint PK_Balance PRIMARY KEY(idBalance)
   Constraint FK_FixedAssets Foreign Key(idFixedAssets) references FixedAssets(idFixedAssets)
   ON DELETE CASCADE ON UPDATE CASCADE
   )


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class Report3 : Form
    {
        public Report3()
        {
            InitializeComponent();
        }
        public int stat;

        private void Report3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "workTime_skDataSet4.Out_view". При необходимости она может быть перемещена или удалена.
            this.out_viewTableAdapter.Fill(this.workTime_skDataSet4.Out_view);
            if (stat == 3)
            {
                reportViewer1.Visible = true;
                reportViewer1.Dock = DockStyle.Fill;
                this.out_viewTableAdapter.Fill(this.workTime_skDataSet4.Out_view);
                this.reportViewer1.RefreshReport();

                // TODO: данная строка кода позволяет загрузить данные в таблицу "workTime_skDataSet4.Out_view". При необходимости она может быть перемещена или удалена.
            }

            this.reportViewer1.RefreshReport();
        }
    }
}

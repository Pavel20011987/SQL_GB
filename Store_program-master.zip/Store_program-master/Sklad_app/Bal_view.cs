﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Sklad_app
{
    public partial class Bal_view : Form
    {
        public Bal_view()
        {
            InitializeComponent();
        }

        private void bal_viewBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bal_viewBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bal_view1);

        }

        private void Bal_view_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bal_view1._Bal_view". При необходимости она может быть перемещена или удалена.
            //this.bal_viewTableAdapter.Fill(this.bal_view1._Bal_view);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.bal_viewTableAdapter.Fill(this.bal_view1._Bal_view);
        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            new_edit_del_butt_controler();
            this.bal_viewBindingSource.AddNew();
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            //----------------------------------
            Int32 rc;
            rc = this.bal_view1._Bal_view.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            //---------------------------------
            Int32 rc;
            rc = this.bal_view1._Bal_view.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
            this.bal_viewBindingSource.RemoveCurrent();
            //-----------------------------------------
            this.groupBox1.Enabled = false;
        }
        void new_edit_del_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = false;
            this.Edit_butt.Enabled = false;
            this.Del_butt.Enabled = false;
            //------------------------------------
            this.save_butt.Enabled = true;
            this.cancel_butt.Enabled = true;
            //------------------------------------
            this.groupBox1.Enabled = true;
            this.bal_viewDataGridView.Enabled = false;
            this.bal_viewBindingNavigator.Enabled = false;
            //-------------------------------------
        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.Validate();
            this.bal_viewBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.bal_viewTableAdapter.Update(this.bal_view1._Bal_view);
            if (r > 0)
            {
                MessageBox.Show("Сохранено! Счетчик: " + r.ToString());
            }
            else
            {
                MessageBox.Show("Ничего не сохранилось! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.bal_viewBindingSource.CancelEdit();
            this.bal_view1._Bal_view.RejectChanges();
        }
        void save_cancel_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = true;
            this.Edit_butt.Enabled = true;
            this.Del_butt.Enabled = true;
            //------------------------------------
            this.save_butt.Enabled = false;
            this.cancel_butt.Enabled = false;
            //------------------------------------
            this.groupBox1.Enabled = false;
            this.bal_viewDataGridView.Enabled = true;
            this.bal_viewBindingNavigator.Enabled = true;
            //------------------------------------
        }
    }
}

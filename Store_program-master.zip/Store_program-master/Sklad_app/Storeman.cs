﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class Storeman : Form
    {
        public Storeman()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sklad_app.sixth_form.sixth_form_main FFixed = new sixth_form.sixth_form_main();

            FFixed.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Inflows_view Finflows_View = new Inflows_view();
            Finflows_View.Show();
        }

        private void основныеСредстваНаСкладеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sklad_app.sixth_form.sixth_form_main FFixed = new sixth_form.sixth_form_main();

            FFixed.Show();
        }

        private void приходОСНаСкладToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inflows_view Finflows_View = new Inflows_view();
            Finflows_View.Show();
        }
    }
}

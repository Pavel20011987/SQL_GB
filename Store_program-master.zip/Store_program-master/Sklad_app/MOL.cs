﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class MOL : Form
    {
        public MOL()
        {
            InitializeComponent();
        }

       // private void materiallyResponsiblePersonBindingNavigatorSaveItem_Click(object sender, EventArgs e)
       // {
       //     this.Validate();
        //    this.materiallyResponsiblePersonBindingSource.EndEdit();
        //    this.tableAdapterManager.UpdateAll(this.mOL1);

        //}

        private void MOL_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mOL1.MateriallyResponsiblePerson". При необходимости она может быть перемещена или удалена.
           // this.materiallyResponsiblePersonTableAdapter.Fill(this.mOL1.MateriallyResponsiblePerson);

        }

        private void materiallyResponsiblePersonBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.materiallyResponsiblePersonTableAdapter.Fill(this.mOL1.MateriallyResponsiblePerson);
        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            new_edit_del_butt_controler();
            this.materiallyResponsiblePersonBindingSource.AddNew();
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            //----------------------------------
            Int32 rc;
            rc = this.mOL1.MateriallyResponsiblePerson.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Please select your record to edit!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            //---------------------------------
            Int32 rc;
            rc = this.mOL1.MateriallyResponsiblePerson.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Please select your record to delete!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
            this.materiallyResponsiblePersonBindingSource.RemoveCurrent();
            //-----------------------------------------
            this.groupBox1.Enabled = false;
        }
         void new_edit_del_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = false;
            this.Edit_butt.Enabled = false;
            this.Del_butt.Enabled = false;
            //------------------------------------
            this.save_butt.Enabled = true;
            this.cancel_butt.Enabled = true;
            //------------------------------------
            this.groupBox1.Enabled = true;
            this.materiallyResponsiblePersonDataGridView.Enabled = false;
            this.materiallyResponsiblePersonBindingNavigator.Enabled = false;
            //-------------------------------------
        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.Validate();
            this.materiallyResponsiblePersonBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.materiallyResponsiblePersonTableAdapter.Update(this.mOL1.MateriallyResponsiblePerson);
            if (r > 0)
            {
                MessageBox.Show("Done! Count: " + r.ToString());
            }
            else
            {
                MessageBox.Show("Nothing Saved! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.materiallyResponsiblePersonBindingSource.CancelEdit();
            this.mOL1.MateriallyResponsiblePerson.RejectChanges();
        }
        void save_cancel_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = true;
            this.Edit_butt.Enabled = true;
            this.Del_butt.Enabled = true;
            //------------------------------------
            this.save_butt.Enabled = false;
            this.cancel_butt.Enabled = false;
            //------------------------------------
            this.groupBox1.Enabled = false;
            this.materiallyResponsiblePersonDataGridView.Enabled = true;
            this.materiallyResponsiblePersonBindingNavigator.Enabled = true;
            //------------------------------------
        }
    }
}

﻿
namespace Sklad_app
{
    partial class MOL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MOL));
            System.Windows.Forms.Label idMateriallyResponsiblePersonLabel;
            System.Windows.Forms.Label surnameLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label patronimicLabel;
            this.mOL1 = new Sklad_app.Dataset.MOL();
            this.materiallyResponsiblePersonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.materiallyResponsiblePersonTableAdapter = new Sklad_app.Dataset.MOLTableAdapters.MateriallyResponsiblePersonTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.MOLTableAdapters.TableAdapterManager();
            this.materiallyResponsiblePersonBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.materiallyResponsiblePersonDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idMateriallyResponsiblePersonTextBox = new System.Windows.Forms.TextBox();
            this.surnameTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.patronimicTextBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.Add_butt = new System.Windows.Forms.Button();
            idMateriallyResponsiblePersonLabel = new System.Windows.Forms.Label();
            surnameLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            patronimicLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.mOL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materiallyResponsiblePersonBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materiallyResponsiblePersonBindingNavigator)).BeginInit();
            this.materiallyResponsiblePersonBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.materiallyResponsiblePersonDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mOL1
            // 
            this.mOL1.DataSetName = "MOL";
            this.mOL1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // materiallyResponsiblePersonBindingSource
            // 
            this.materiallyResponsiblePersonBindingSource.DataMember = "MateriallyResponsiblePerson";
            this.materiallyResponsiblePersonBindingSource.DataSource = this.mOL1;
            // 
            // materiallyResponsiblePersonTableAdapter
            // 
            this.materiallyResponsiblePersonTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MateriallyResponsiblePersonTableAdapter = this.materiallyResponsiblePersonTableAdapter;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.MOLTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // materiallyResponsiblePersonBindingNavigator
            // 
            this.materiallyResponsiblePersonBindingNavigator.AddNewItem = null;
            this.materiallyResponsiblePersonBindingNavigator.BindingSource = this.materiallyResponsiblePersonBindingSource;
            this.materiallyResponsiblePersonBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.materiallyResponsiblePersonBindingNavigator.DeleteItem = null;
            this.materiallyResponsiblePersonBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.materiallyResponsiblePersonBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.materiallyResponsiblePersonBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.materiallyResponsiblePersonBindingNavigator.Location = new System.Drawing.Point(0, 730);
            this.materiallyResponsiblePersonBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.materiallyResponsiblePersonBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.materiallyResponsiblePersonBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.materiallyResponsiblePersonBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.materiallyResponsiblePersonBindingNavigator.Name = "materiallyResponsiblePersonBindingNavigator";
            this.materiallyResponsiblePersonBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.materiallyResponsiblePersonBindingNavigator.Size = new System.Drawing.Size(761, 27);
            this.materiallyResponsiblePersonBindingNavigator.TabIndex = 0;
            this.materiallyResponsiblePersonBindingNavigator.Text = "bindingNavigator1";
            this.materiallyResponsiblePersonBindingNavigator.RefreshItems += new System.EventHandler(this.materiallyResponsiblePersonBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // materiallyResponsiblePersonDataGridView
            // 
            this.materiallyResponsiblePersonDataGridView.AutoGenerateColumns = false;
            this.materiallyResponsiblePersonDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.materiallyResponsiblePersonDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.materiallyResponsiblePersonDataGridView.DataSource = this.materiallyResponsiblePersonBindingSource;
            this.materiallyResponsiblePersonDataGridView.Location = new System.Drawing.Point(12, 416);
            this.materiallyResponsiblePersonDataGridView.Name = "materiallyResponsiblePersonDataGridView";
            this.materiallyResponsiblePersonDataGridView.RowHeadersWidth = 51;
            this.materiallyResponsiblePersonDataGridView.RowTemplate.Height = 24;
            this.materiallyResponsiblePersonDataGridView.Size = new System.Drawing.Size(620, 220);
            this.materiallyResponsiblePersonDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idMateriallyResponsiblePerson";
            this.dataGridViewTextBoxColumn1.HeaderText = "idMateriallyResponsiblePerson";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn2.HeaderText = "Surname";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Name";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Patronimic";
            this.dataGridViewTextBoxColumn4.HeaderText = "Patronimic";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(435, 672);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 40);
            this.button1.TabIndex = 7;
            this.button1.Text = "Загрузить все данные";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(idMateriallyResponsiblePersonLabel);
            this.groupBox1.Controls.Add(this.idMateriallyResponsiblePersonTextBox);
            this.groupBox1.Controls.Add(surnameLabel);
            this.groupBox1.Controls.Add(this.surnameTextBox);
            this.groupBox1.Controls.Add(nameLabel);
            this.groupBox1.Controls.Add(this.nameTextBox);
            this.groupBox1.Controls.Add(patronimicLabel);
            this.groupBox1.Controls.Add(this.patronimicTextBox);
            this.groupBox1.Location = new System.Drawing.Point(23, 180);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(609, 202);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация";
            // 
            // idMateriallyResponsiblePersonLabel
            // 
            idMateriallyResponsiblePersonLabel.AutoSize = true;
            idMateriallyResponsiblePersonLabel.Location = new System.Drawing.Point(194, 64);
            idMateriallyResponsiblePersonLabel.Name = "idMateriallyResponsiblePersonLabel";
            idMateriallyResponsiblePersonLabel.Size = new System.Drawing.Size(73, 17);
            idMateriallyResponsiblePersonLabel.TabIndex = 0;
            idMateriallyResponsiblePersonLabel.Text = "Код МОЛ:";
            // 
            // idMateriallyResponsiblePersonTextBox
            // 
            this.idMateriallyResponsiblePersonTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materiallyResponsiblePersonBindingSource, "idMateriallyResponsiblePerson", true));
            this.idMateriallyResponsiblePersonTextBox.Location = new System.Drawing.Point(330, 61);
            this.idMateriallyResponsiblePersonTextBox.Name = "idMateriallyResponsiblePersonTextBox";
            this.idMateriallyResponsiblePersonTextBox.Size = new System.Drawing.Size(100, 22);
            this.idMateriallyResponsiblePersonTextBox.TabIndex = 1;
            // 
            // surnameLabel
            // 
            surnameLabel.AutoSize = true;
            surnameLabel.Location = new System.Drawing.Point(194, 92);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new System.Drawing.Size(74, 17);
            surnameLabel.TabIndex = 2;
            surnameLabel.Text = "Фамилия:";
            // 
            // surnameTextBox
            // 
            this.surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materiallyResponsiblePersonBindingSource, "Surname", true));
            this.surnameTextBox.Location = new System.Drawing.Point(330, 89);
            this.surnameTextBox.Name = "surnameTextBox";
            this.surnameTextBox.Size = new System.Drawing.Size(100, 22);
            this.surnameTextBox.TabIndex = 3;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(194, 120);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(39, 17);
            nameLabel.TabIndex = 4;
            nameLabel.Text = "Имя:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materiallyResponsiblePersonBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(330, 117);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 22);
            this.nameTextBox.TabIndex = 5;
            // 
            // patronimicLabel
            // 
            patronimicLabel.AutoSize = true;
            patronimicLabel.Location = new System.Drawing.Point(194, 148);
            patronimicLabel.Name = "patronimicLabel";
            patronimicLabel.Size = new System.Drawing.Size(75, 17);
            patronimicLabel.TabIndex = 6;
            patronimicLabel.Text = "Отчество:";
            // 
            // patronimicTextBox
            // 
            this.patronimicTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materiallyResponsiblePersonBindingSource, "Patronimic", true));
            this.patronimicTextBox.Location = new System.Drawing.Point(330, 145);
            this.patronimicTextBox.Name = "patronimicTextBox";
            this.patronimicTextBox.Size = new System.Drawing.Size(100, 22);
            this.patronimicTextBox.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Controls.Add(this.Del_butt);
            this.panel1.Controls.Add(this.Edit_butt);
            this.panel1.Controls.Add(this.Add_butt);
            this.panel1.Location = new System.Drawing.Point(12, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(740, 87);
            this.panel1.TabIndex = 9;
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(594, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(455, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(329, 4);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 2;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            this.Del_butt.Click += new System.EventHandler(this.Del_butt_Click);
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(160, 4);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 1;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            this.Edit_butt.Click += new System.EventHandler(this.Edit_butt_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(16, 4);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(134, 71);
            this.Add_butt.TabIndex = 0;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            this.Add_butt.Click += new System.EventHandler(this.Add_butt_Click);
            // 
            // MOL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(761, 757);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.materiallyResponsiblePersonDataGridView);
            this.Controls.Add(this.materiallyResponsiblePersonBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MOL";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Материально-ответственное лицо";
            this.Load += new System.EventHandler(this.MOL_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mOL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materiallyResponsiblePersonBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materiallyResponsiblePersonBindingNavigator)).EndInit();
            this.materiallyResponsiblePersonBindingNavigator.ResumeLayout(false);
            this.materiallyResponsiblePersonBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.materiallyResponsiblePersonDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Dataset.MOL mOL1;
        private System.Windows.Forms.BindingSource materiallyResponsiblePersonBindingSource;
        private Dataset.MOLTableAdapters.MateriallyResponsiblePersonTableAdapter materiallyResponsiblePersonTableAdapter;
        private Dataset.MOLTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator materiallyResponsiblePersonBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView materiallyResponsiblePersonDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox idMateriallyResponsiblePersonTextBox;
        private System.Windows.Forms.TextBox surnameTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox patronimicTextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Button Add_butt;
    }
}
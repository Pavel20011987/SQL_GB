﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class Inflows_view : Form
    {
        public Inflows_view()
        {
            InitializeComponent();
        }

        private void inflows_viewBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.inflows_viewBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.inflows_view1);

        }

        private void Inflows_view_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "inflows_view1._Inflows_view". При необходимости она может быть перемещена или удалена.
           // this.inflows_viewTableAdapter.Fill(this.inflows_view1._Inflows_view);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.inflows_viewTableAdapter.Fill(this.inflows_view1._Inflows_view);
        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            new_edit_del_butt_controler();
            this.inflows_viewBindingSource.AddNew();
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            //----------------------------------
            Int32 rc;
            rc = this.inflows_view1._Inflows_view.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            //---------------------------------
            Int32 rc;
            rc = this.inflows_view1._Inflows_view.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
            this.inflows_viewBindingSource.RemoveCurrent();
            //-----------------------------------------
            this.groupBox1.Enabled = false;
        }
        void new_edit_del_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = false;
            this.Edit_butt.Enabled = false;
            this.Del_butt.Enabled = false;
            //------------------------------------
            this.save_butt.Enabled = true;
            this.cancel_butt.Enabled = true;
            //------------------------------------
            this.groupBox1.Enabled = true;
            this.inflows_viewDataGridView.Enabled = false;
            this.inflows_viewBindingNavigator.Enabled = false;
            //-------------------------------------
        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.Validate();
            this.inflows_viewBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.inflows_viewTableAdapter.Update(this.inflows_view1._Inflows_view);
            if (r > 0)
            {
                MessageBox.Show("Сохранено! Счетчик: " + r.ToString());
            }
            else
            {
                MessageBox.Show("Ничего не сохранилось! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.inflows_viewBindingSource.CancelEdit();
            this.inflows_view1._Inflows_view.RejectChanges();
        }
        void save_cancel_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = true;
            this.Edit_butt.Enabled = true;
            this.Del_butt.Enabled = true;
            //------------------------------------
            this.save_butt.Enabled = false;
            this.cancel_butt.Enabled = false;
            //------------------------------------
            this.groupBox1.Enabled = false;
            this.inflows_viewDataGridView.Enabled = true;
            this.inflows_viewBindingNavigator.Enabled = true;
            //------------------------------------
        }
    }
}

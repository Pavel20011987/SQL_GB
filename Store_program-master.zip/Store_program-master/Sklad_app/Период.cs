﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class Период : Form
    {
        public Период()
        {
            InitializeComponent();
        }
        public int stat;
        private void button1_Click(object sender, EventArgs e)
        {
            Report2 o = new Report2();
            o.stat = stat;
            o.dat1 = dateTimePicker1.Text;
            o.dat2 = dateTimePicker2.Text;
            o.Show();
            Close();
        }

        private void Период_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

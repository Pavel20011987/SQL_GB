﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using Microsoft.ReportingServices.ReportPublishing;
using Sklad_app;
namespace Sklad_app
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }
        public int stat, kod;
        public string dat1, dat2;
       

        private void Report_Load(object sender, EventArgs e)
        {
            //DateFrom = dateTimePicker_from.Value.AddDays(-1).ToString();
            //DateTo = dateTimePicker_to.Value.ToString();

            //ReportParameter DateFromParam = new ReportParameter("ReportParameterDateFrom", dat1);
            //ReportParameter DateToParam = new ReportParameter("ReportParameterDateTo", dat2);
            //Bal_viewTableAdapter.Report.SetParameters(DateFromParam);
            //Bal_viewTableAdapter.Report.SetParameters(DateToParam);
            //reportViewer1.LocalReport.SetParameters(DateFromParam);
            //reportViewer1.LocalReport.SetParameters(DateToParam);

            // TODO: данная строка кода позволяет загрузить данные в таблицу "WorkTime_skDataSet.Bal_view". При необходимости она может быть перемещена или удалена.
            //this.Bal_viewTableAdapter.Fill(this.WorkTime_skDataSet.Bal_view, Convert.ToDateTime(dat1), Convert.ToDateTime(dat2));

           // this.reportViewer1.RefreshReport();
            //if (stat == 1)
            //{
              //  reportViewer1.Visible = true;
                //reportViewer1.Dock = DockStyle.Fill;
                //this.Bal_viewTableAdapter.Fill(this.WorkTime_skDataSet.Bal_view);
                //this.reportViewer1.RefreshReport();
            //}
            if (stat == 2)
            {
                reportViewer1.Visible = true;
                reportViewer1.Dock = DockStyle.Fill;
                this.Bal_view_sumTableAdapter.Fill(this.WorkTime_skDataSet1.Bal_view_sum);
                this.reportViewer1.RefreshReport();
            }
        }
    }
}

﻿namespace Sklad_app
{
    partial class Report2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.workTime_skDataSet2 = new Sklad_app.WorkTime_skDataSet2();
            this.workTimeskDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fixedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fixedTableAdapter = new Sklad_app.WorkTime_skDataSet2TableAdapters.FixedTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.workTime_skDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workTimeskDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.fixedBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sklad_app.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(23, 30);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(763, 424);
            this.reportViewer1.TabIndex = 0;
            // 
            // workTime_skDataSet2
            // 
            this.workTime_skDataSet2.DataSetName = "WorkTime_skDataSet2";
            this.workTime_skDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // workTimeskDataSet2BindingSource
            // 
            this.workTimeskDataSet2BindingSource.DataSource = this.workTime_skDataSet2;
            this.workTimeskDataSet2BindingSource.Position = 0;
            // 
            // fixedBindingSource
            // 
            this.fixedBindingSource.DataMember = "Fixed";
            this.fixedBindingSource.DataSource = this.workTimeskDataSet2BindingSource;
            // 
            // fixedTableAdapter
            // 
            this.fixedTableAdapter.ClearBeforeFill = true;
            // 
            // Report2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 492);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Report2";
            this.Text = "Report2";
            this.Load += new System.EventHandler(this.Report2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.workTime_skDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workTimeskDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private WorkTime_skDataSet2 workTime_skDataSet2;
        private System.Windows.Forms.BindingSource workTimeskDataSet2BindingSource;
        private System.Windows.Forms.BindingSource fixedBindingSource;
        private WorkTime_skDataSet2TableAdapters.FixedTableAdapter fixedTableAdapter;
    }
}
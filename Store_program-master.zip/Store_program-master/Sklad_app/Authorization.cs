﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class Authorization : Form
    {
        SqlConnection sqlConnection;
        
          public Authorization()
        {
            InitializeComponent();
        }

        private async void button_enter_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=HOME-PC;Initial Catalog=WorkTime_sk;Integrated Security=True";
            sqlConnection = new SqlConnection(connectionString);

            await sqlConnection.OpenAsync();

            SqlDataReader sqlReader = null;

            SqlCommand command = new SqlCommand("SELECT [Password], [KodUser] FROM [Users] WHERE [NameUser]=@NameUser", sqlConnection);

            command.Parameters.AddWithValue("NameUser", textBox_login.Text);

            await command.ExecuteNonQueryAsync();

            string str = null;
            try
            {
                sqlReader = await command.ExecuteReaderAsync();
                while (await sqlReader.ReadAsync())
                {
                    str = Convert.ToString(sqlReader["Password"]);
                    Data.userId = Convert.ToInt32(sqlReader["KodUser"]);
                }
            }
            catch (Exception exp1)
            {
                MessageBox.Show(exp1.Message.ToString(), exp1.Source.ToString(), MessageBoxButtons.OK);
            }
            finally
            {
                if (sqlReader != null)
                {
                    sqlReader.Close();
                }
            }

            if (textBox_password.Text == "")
            {
                //выход на др форму
               // MainForm r = new MainForm();
                //r.Show();
                //this.Hide();
                MessageBox.Show("Вы не ввели пароль!");
            }
            
            else
            {
                if (textBox_password.Text == "111")
                {
                  MainForm r = new MainForm();
                  r.Show();
                  this.Hide();
                }
                else if (textBox_password.Text == "pass2")
                {
                    Accountant a = new Accountant();
                    a.Show();
                    this.Hide();
                }
                else if (textBox_password.Text == "121")
                {
                   Storeman s = new Storeman();
                    s.Show();
                    this.Hide();
                }
                else 
                {
                    MessageBox.Show("Неправильно введен логин или пароль!");
                }
            }
            
        }

        
            }

    






            public static class Data 
    {
        public static int userId = 26;
    }

        }
  

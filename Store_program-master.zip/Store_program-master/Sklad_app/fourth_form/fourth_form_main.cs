﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.fourth_form
{
    public partial class fourth_form_main : Form
    {
        public fourth_form_main()
        {
            InitializeComponent();
        }

        //private void outlayBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        //{
          //  this.Validate();
          //  this.outlayBindingSource.EndEdit();
        //    this.tableAdapterManager.UpdateAll(this.outlay);

        //}

        private void fourth_form_main_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "outlay._Outlay". При необходимости она может быть перемещена или удалена.
            this.outlayTableAdapter.Fill(this.outlay._Outlay);

        }

        private void outlayBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.fourth_form.fourth_form_child frm = new fourth_form_child();
            frm.st_lb.Text = "Новое значение";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.outlayTableAdapter.Fill(this.outlay._Outlay);
            }

            //-----------------------------------------
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            Int32 rn;
            rn = this.outlay._Outlay.Rows.Count;
            if (rn == 0)
            {
                MessageBox.Show("Please select your record to edit!");
                return;
            }
            Sklad_app.fourth_form.fourth_form_child frm = new fourth_form_child();
            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idOutlayLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.st_lb.Text = "Значение для редактирования";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.outlayTableAdapter.Fill(this.outlay._Outlay);
            }

            //-----------------------------------------
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.fourth_form.fourth_form_child frm = new fourth_form_child();

            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idOutlayLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.Sel_id_lb.Text = this.idOutlayLabel1.Text;
            frm.st_lb.Text = "Значение для удаления";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.outlayTableAdapter.Fill(this.outlay._Outlay);
            }

            //-----------------------------------------
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.outlayTableAdapter.Fill(this.outlay._Outlay);
        }
    }
}

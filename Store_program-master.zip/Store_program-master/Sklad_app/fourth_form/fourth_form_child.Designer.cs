﻿
namespace Sklad_app.fourth_form
{
    partial class fourth_form_child
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label idOutlayLabel;
            System.Windows.Forms.Label idFixedAssetsLabel;
            System.Windows.Forms.Label costToDateLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label priceLabel;
            this.Sel_id_lb = new System.Windows.Forms.Label();
            this.Add_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idOutlayTextBox = new System.Windows.Forms.TextBox();
            this.outlayBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.outlay = new Sklad_app.Dataset.Outlay();
            this.idFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.costToDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.st_lb = new System.Windows.Forms.Label();
            this.outlayTableAdapter = new Sklad_app.Dataset.OutlayTableAdapters.OutlayTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.OutlayTableAdapters.TableAdapterManager();
            label1 = new System.Windows.Forms.Label();
            idOutlayLabel = new System.Windows.Forms.Label();
            idFixedAssetsLabel = new System.Windows.Forms.Label();
            costToDateLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            priceLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.outlayBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.outlay)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label1.Location = new System.Drawing.Point(15, 16);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(73, 20);
            label1.TabIndex = 3;
            label1.Text = "Статус:";
            // 
            // idOutlayLabel
            // 
            idOutlayLabel.AutoSize = true;
            idOutlayLabel.Location = new System.Drawing.Point(73, 106);
            idOutlayLabel.Name = "idOutlayLabel";
            idOutlayLabel.Size = new System.Drawing.Size(101, 17);
            idOutlayLabel.TabIndex = 0;
            idOutlayLabel.Text = "Код расходов:";
            // 
            // idFixedAssetsLabel
            // 
            idFixedAssetsLabel.AutoSize = true;
            idFixedAssetsLabel.Location = new System.Drawing.Point(73, 134);
            idFixedAssetsLabel.Name = "idFixedAssetsLabel";
            idFixedAssetsLabel.Size = new System.Drawing.Size(61, 17);
            idFixedAssetsLabel.TabIndex = 2;
            idFixedAssetsLabel.Text = "Код ОС:";
            // 
            // costToDateLabel
            // 
            costToDateLabel.AutoSize = true;
            costToDateLabel.Location = new System.Drawing.Point(73, 163);
            costToDateLabel.Name = "costToDateLabel";
            costToDateLabel.Size = new System.Drawing.Size(103, 17);
            costToDateLabel.TabIndex = 4;
            costToDateLabel.Text = "Дата расхода:";
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(73, 190);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(90, 17);
            quantityLabel.TabIndex = 6;
            quantityLabel.Text = "Количество:";
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Location = new System.Drawing.Point(73, 218);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new System.Drawing.Size(47, 17);
            priceLabel.TabIndex = 8;
            priceLabel.Text = "Цена:";
            // 
            // Sel_id_lb
            // 
            this.Sel_id_lb.AutoSize = true;
            this.Sel_id_lb.Location = new System.Drawing.Point(821, 247);
            this.Sel_id_lb.Name = "Sel_id_lb";
            this.Sel_id_lb.Size = new System.Drawing.Size(45, 17);
            this.Sel_id_lb.TabIndex = 8;
            this.Sel_id_lb.Text = "sel id:";
            this.Sel_id_lb.Click += new System.EventHandler(this.Sel_id_lb_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(873, 235);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(109, 71);
            this.Add_butt.TabIndex = 9;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(1161, 235);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 11;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(990, 235);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 10;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(481, 87);
            this.panel1.TabIndex = 12;
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(171, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(10, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(idOutlayLabel);
            this.groupBox1.Controls.Add(this.idOutlayTextBox);
            this.groupBox1.Controls.Add(idFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.idFixedAssetsTextBox);
            this.groupBox1.Controls.Add(costToDateLabel);
            this.groupBox1.Controls.Add(this.costToDateDateTimePicker);
            this.groupBox1.Controls.Add(quantityLabel);
            this.groupBox1.Controls.Add(this.quantityTextBox);
            this.groupBox1.Controls.Add(priceLabel);
            this.groupBox1.Controls.Add(this.priceTextBox);
            this.groupBox1.Location = new System.Drawing.Point(13, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(471, 327);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация";
            // 
            // idOutlayTextBox
            // 
            this.idOutlayTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.outlayBindingSource, "idOutlay", true));
            this.idOutlayTextBox.Location = new System.Drawing.Point(185, 103);
            this.idOutlayTextBox.Name = "idOutlayTextBox";
            this.idOutlayTextBox.ReadOnly = true;
            this.idOutlayTextBox.Size = new System.Drawing.Size(200, 22);
            this.idOutlayTextBox.TabIndex = 1;
            // 
            // outlayBindingSource
            // 
            this.outlayBindingSource.DataMember = "Outlay";
            this.outlayBindingSource.DataSource = this.outlay;
            // 
            // outlay
            // 
            this.outlay.DataSetName = "Outlay";
            this.outlay.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // idFixedAssetsTextBox
            // 
            this.idFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.outlayBindingSource, "idFixedAssets", true));
            this.idFixedAssetsTextBox.Location = new System.Drawing.Point(185, 131);
            this.idFixedAssetsTextBox.Name = "idFixedAssetsTextBox";
            this.idFixedAssetsTextBox.Size = new System.Drawing.Size(200, 22);
            this.idFixedAssetsTextBox.TabIndex = 3;
            // 
            // costToDateDateTimePicker
            // 
            this.costToDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.outlayBindingSource, "CostToDate", true));
            this.costToDateDateTimePicker.Location = new System.Drawing.Point(185, 159);
            this.costToDateDateTimePicker.Name = "costToDateDateTimePicker";
            this.costToDateDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.costToDateDateTimePicker.TabIndex = 5;
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.outlayBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(185, 187);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(200, 22);
            this.quantityTextBox.TabIndex = 7;
            // 
            // priceTextBox
            // 
            this.priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.outlayBindingSource, "Price", true));
            this.priceTextBox.Location = new System.Drawing.Point(185, 215);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(200, 22);
            this.priceTextBox.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.st_lb);
            this.panel2.Controls.Add(label1);
            this.panel2.Location = new System.Drawing.Point(13, 472);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(469, 71);
            this.panel2.TabIndex = 14;
            // 
            // st_lb
            // 
            this.st_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.st_lb.ForeColor = System.Drawing.Color.Maroon;
            this.st_lb.Location = new System.Drawing.Point(94, 16);
            this.st_lb.Name = "st_lb";
            this.st_lb.Size = new System.Drawing.Size(357, 20);
            this.st_lb.TabIndex = 4;
            this.st_lb.Text = "-";
            this.st_lb.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // outlayTableAdapter
            // 
            this.outlayTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.OutlayTableAdapter = this.outlayTableAdapter;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.OutlayTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // fourth_form_child
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(511, 555);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Add_butt);
            this.Controls.Add(this.Del_butt);
            this.Controls.Add(this.Edit_butt);
            this.Controls.Add(this.Sel_id_lb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fourth_form_child";
            this.ShowIcon = false;
            this.Text = "fourth_form_child";
            this.Load += new System.EventHandler(this.fourth_form_child_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.outlayBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.outlay)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label Sel_id_lb;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label st_lb;
        private Dataset.Outlay outlay;
        private System.Windows.Forms.BindingSource outlayBindingSource;
        private Dataset.OutlayTableAdapters.OutlayTableAdapter outlayTableAdapter;
        private Dataset.OutlayTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox idOutlayTextBox;
        private System.Windows.Forms.TextBox idFixedAssetsTextBox;
        private System.Windows.Forms.DateTimePicker costToDateDateTimePicker;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.fifth_form
{
    public partial class fifth_form_child : Form
    {
        public fifth_form_child()
        {
            InitializeComponent();
        }

        private void out_viewBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.out_viewBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.out_view);

        }

        private void fifth_form_child_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "out_view._Out_view". При необходимости она может быть перемещена или удалена.
            //this.out_viewTableAdapter.Fill(this.out_view._Out_view);
            if (this.st_lb.Text == "Новое значение")
            {
                this.out_viewBindingSource.AddNew();
                this.groupBox1.Enabled = true;
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для редактирования")
            {
                this.groupBox1.Enabled = true;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.out_viewTableAdapter.FillBy(this.out_view._Out_view, (int)i);
                //------------------------------------------------
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.groupBox1.Enabled = false;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.out_viewTableAdapter.FillBy(this.out_view._Out_view, (int)i);
                //------------------------------------------------
            }

        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.out_viewBindingSource.RemoveCurrent();
            }

            this.Validate();
            this.out_viewBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.out_viewTableAdapter.Update(this.out_view._Out_view);
            if (r > 0)
            {
                MessageBox.Show("Сохранено! Счетчик: " + r.ToString());
                // this.Close();
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Ничего не сохранилось! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            // this.Close();
            this.DialogResult = DialogResult.Cancel;
        }
    }
}

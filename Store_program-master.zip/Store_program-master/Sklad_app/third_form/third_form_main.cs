﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.third_form
{
    public partial class third_form_main : Form
    {
        public third_form_main()
        {
            InitializeComponent();
        }

      //  private void inflowsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
       // {
       //     this.Validate();
      //      this.inflowsBindingSource.EndEdit();
      //      this.tableAdapterManager.UpdateAll(this.inflows);

      //  }

        private void third_form_main_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "inflows._Inflows". При необходимости она может быть перемещена или удалена.
            this.inflowsTableAdapter.Fill(this.inflows._Inflows);

        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.third_form.third_form_child frm = new third_form_child();
            frm.st_lb.Text = "Новое значение";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.inflowsTableAdapter.Fill(this.inflows._Inflows);
            }

            //-----------------------------------------
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            Int32 rn;
            rn = this.inflows._Inflows.Rows.Count;
            if (rn == 0)
            {
                MessageBox.Show("Please select your record to edit!");
                return;
            }
            Sklad_app.third_form.third_form_child frm = new third_form_child();
            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idInflowsLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.st_lb.Text = "Значение для редактирования";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.inflowsTableAdapter.Fill(this.inflows._Inflows);
            }

            //-----------------------------------------
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.third_form.third_form_child frm = new third_form_child();

            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idInflowsLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.Sel_id_lb.Text = this.idInflowsLabel1.Text;
            frm.st_lb.Text = "Значение для удаления";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.inflowsTableAdapter.Fill(this.inflows._Inflows);
            }

            //-----------------------------------------
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.inflowsTableAdapter.Fill(this.inflows._Inflows);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.third_form
{
    public partial class third_form_child : Form
    {
        public third_form_child()
        {
            InitializeComponent();
        }

      //  private void inflowsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        //{
         //   this.Validate();
       //     this.inflowsBindingSource.EndEdit();
       //     this.tableAdapterManager.UpdateAll(this.inflows);

       // }

       // private void inflowsBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
       // {
       //     this.Validate();
      //      this.inflowsBindingSource.EndEdit();
      //      this.tableAdapterManager.UpdateAll(this.inflows);

      //  }

        private void third_form_child_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "inflows._Inflows". При необходимости она может быть перемещена или удалена.
           // this.inflowsTableAdapter.Fill(this.inflows._Inflows);
            if (this.st_lb.Text == "Новое значение")
            {
                this.inflowsBindingSource.AddNew();
                this.groupBox1.Enabled = true;
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для редактирования")
            {
                this.groupBox1.Enabled = true;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.inflowsTableAdapter.FillBy_id(this.inflows._Inflows, (int)i);
                //------------------------------------------------
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.groupBox1.Enabled = false;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.inflowsTableAdapter.FillBy_id(this.inflows._Inflows, (int)i);
                //------------------------------------------------
            }


        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.inflowsBindingSource.RemoveCurrent();
            }

            this.Validate();
            this.inflowsBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.inflowsTableAdapter.Update(this.inflows._Inflows);
            if (r > 0)
            {
                MessageBox.Show("Done! Count: " + r.ToString());
                // this.Close();
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Nothing Saved! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            // this.Close();
            this.DialogResult = DialogResult.Cancel;
        }
    }
}

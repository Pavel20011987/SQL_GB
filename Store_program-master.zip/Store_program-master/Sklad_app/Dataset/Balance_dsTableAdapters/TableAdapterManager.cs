﻿namespace Sklad_app.Dataset.Balance_dsTableAdapters
{
  //  internal class TableAdapterManager
   // {
  //  }
}
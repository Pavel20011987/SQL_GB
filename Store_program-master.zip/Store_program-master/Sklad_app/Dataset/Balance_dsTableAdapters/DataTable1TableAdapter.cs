﻿namespace Sklad_app.Dataset.Balance_dsTableAdapters
{
    internal class DataTable1TableAdapter
    {
    }
}
﻿
namespace Sklad_app
{
    partial class View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(View));
            System.Windows.Forms.Label designationFixedAssetsLabel;
            System.Windows.Forms.Label goldLabel;
            System.Windows.Forms.Label silverLabel;
            System.Windows.Forms.Label platinumLabel;
            System.Windows.Forms.Label platiumGroupMetalLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label surnameLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label patronimicLabel;
            this.view1 = new Sklad_app.Dataset.View();
            this.balance_FixedAssets_MOLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.balance_FixedAssets_MOLTableAdapter = new Sklad_app.Dataset.ViewTableAdapters.Balance_FixedAssets_MOLTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.ViewTableAdapters.TableAdapterManager();
            this.balance_FixedAssets_MOLBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.balance_FixedAssets_MOLDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.Add_butt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.designationFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.goldTextBox = new System.Windows.Forms.TextBox();
            this.silverTextBox = new System.Windows.Forms.TextBox();
            this.platinumTextBox = new System.Windows.Forms.TextBox();
            this.platiumGroupMetalTextBox = new System.Windows.Forms.TextBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.surnameTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.patronimicTextBox = new System.Windows.Forms.TextBox();
            designationFixedAssetsLabel = new System.Windows.Forms.Label();
            goldLabel = new System.Windows.Forms.Label();
            silverLabel = new System.Windows.Forms.Label();
            platinumLabel = new System.Windows.Forms.Label();
            platiumGroupMetalLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            surnameLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            patronimicLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.view1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance_FixedAssets_MOLBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance_FixedAssets_MOLBindingNavigator)).BeginInit();
            this.balance_FixedAssets_MOLBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.balance_FixedAssets_MOLDataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // view1
            // 
            this.view1.DataSetName = "View";
            this.view1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // balance_FixedAssets_MOLBindingSource
            // 
            this.balance_FixedAssets_MOLBindingSource.DataMember = "Balance_FixedAssets_MOL";
            this.balance_FixedAssets_MOLBindingSource.DataSource = this.view1;
            // 
            // balance_FixedAssets_MOLTableAdapter
            // 
            this.balance_FixedAssets_MOLTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.ViewTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // balance_FixedAssets_MOLBindingNavigator
            // 
            this.balance_FixedAssets_MOLBindingNavigator.AddNewItem = null;
            this.balance_FixedAssets_MOLBindingNavigator.BindingSource = this.balance_FixedAssets_MOLBindingSource;
            this.balance_FixedAssets_MOLBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.balance_FixedAssets_MOLBindingNavigator.DeleteItem = null;
            this.balance_FixedAssets_MOLBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.balance_FixedAssets_MOLBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.balance_FixedAssets_MOLBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.balance_FixedAssets_MOLBindingNavigator.Location = new System.Drawing.Point(0, 522);
            this.balance_FixedAssets_MOLBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.balance_FixedAssets_MOLBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.balance_FixedAssets_MOLBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.balance_FixedAssets_MOLBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.balance_FixedAssets_MOLBindingNavigator.Name = "balance_FixedAssets_MOLBindingNavigator";
            this.balance_FixedAssets_MOLBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.balance_FixedAssets_MOLBindingNavigator.Size = new System.Drawing.Size(883, 27);
            this.balance_FixedAssets_MOLBindingNavigator.TabIndex = 0;
            this.balance_FixedAssets_MOLBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // balance_FixedAssets_MOLDataGridView
            // 
            this.balance_FixedAssets_MOLDataGridView.AutoGenerateColumns = false;
            this.balance_FixedAssets_MOLDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.balance_FixedAssets_MOLDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.balance_FixedAssets_MOLDataGridView.DataSource = this.balance_FixedAssets_MOLBindingSource;
            this.balance_FixedAssets_MOLDataGridView.Location = new System.Drawing.Point(0, 304);
            this.balance_FixedAssets_MOLDataGridView.Name = "balance_FixedAssets_MOLDataGridView";
            this.balance_FixedAssets_MOLDataGridView.RowHeadersWidth = 51;
            this.balance_FixedAssets_MOLDataGridView.RowTemplate.Height = 24;
            this.balance_FixedAssets_MOLDataGridView.Size = new System.Drawing.Size(843, 179);
            this.balance_FixedAssets_MOLDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "DesignationFixedAssets";
            this.dataGridViewTextBoxColumn1.HeaderText = "DesignationFixedAssets";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Gold";
            this.dataGridViewTextBoxColumn2.HeaderText = "Gold";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Silver";
            this.dataGridViewTextBoxColumn3.HeaderText = "Silver";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Platinum";
            this.dataGridViewTextBoxColumn4.HeaderText = "Platinum";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PlatiumGroupMetal";
            this.dataGridViewTextBoxColumn5.HeaderText = "PlatiumGroupMetal";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn6.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn7.HeaderText = "Surname";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn8.HeaderText = "Name";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Patronimic";
            this.dataGridViewTextBoxColumn9.HeaderText = "Patronimic";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Controls.Add(this.Del_butt);
            this.panel1.Controls.Add(this.Edit_butt);
            this.panel1.Controls.Add(this.Add_butt);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(740, 87);
            this.panel1.TabIndex = 6;
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(594, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(455, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(329, 4);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 2;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            this.Del_butt.Click += new System.EventHandler(this.Del_butt_Click);
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(160, 4);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 1;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            this.Edit_butt.Click += new System.EventHandler(this.Edit_butt_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(16, 4);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(134, 71);
            this.Add_butt.TabIndex = 0;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            this.Add_butt.Click += new System.EventHandler(this.Add_butt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(designationFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.designationFixedAssetsTextBox);
            this.groupBox1.Controls.Add(goldLabel);
            this.groupBox1.Controls.Add(this.goldTextBox);
            this.groupBox1.Controls.Add(silverLabel);
            this.groupBox1.Controls.Add(this.silverTextBox);
            this.groupBox1.Controls.Add(platinumLabel);
            this.groupBox1.Controls.Add(this.platinumTextBox);
            this.groupBox1.Controls.Add(platiumGroupMetalLabel);
            this.groupBox1.Controls.Add(this.platiumGroupMetalTextBox);
            this.groupBox1.Controls.Add(quantityLabel);
            this.groupBox1.Controls.Add(this.quantityTextBox);
            this.groupBox1.Controls.Add(surnameLabel);
            this.groupBox1.Controls.Add(this.surnameTextBox);
            this.groupBox1.Controls.Add(nameLabel);
            this.groupBox1.Controls.Add(this.nameTextBox);
            this.groupBox1.Controls.Add(patronimicLabel);
            this.groupBox1.Controls.Add(this.patronimicTextBox);
            this.groupBox1.Location = new System.Drawing.Point(30, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(813, 175);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // designationFixedAssetsLabel
            // 
            designationFixedAssetsLabel.AutoSize = true;
            designationFixedAssetsLabel.Location = new System.Drawing.Point(101, 18);
            designationFixedAssetsLabel.Name = "designationFixedAssetsLabel";
            designationFixedAssetsLabel.Size = new System.Drawing.Size(170, 17);
            designationFixedAssetsLabel.TabIndex = 0;
            designationFixedAssetsLabel.Text = "Designation Fixed Assets:";
            // 
            // designationFixedAssetsTextBox
            // 
            this.designationFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "DesignationFixedAssets", true));
            this.designationFixedAssetsTextBox.Location = new System.Drawing.Point(277, 15);
            this.designationFixedAssetsTextBox.Name = "designationFixedAssetsTextBox";
            this.designationFixedAssetsTextBox.Size = new System.Drawing.Size(100, 22);
            this.designationFixedAssetsTextBox.TabIndex = 1;
            // 
            // goldLabel
            // 
            goldLabel.AutoSize = true;
            goldLabel.Location = new System.Drawing.Point(101, 46);
            goldLabel.Name = "goldLabel";
            goldLabel.Size = new System.Drawing.Size(42, 17);
            goldLabel.TabIndex = 2;
            goldLabel.Text = "Gold:";
            // 
            // goldTextBox
            // 
            this.goldTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Gold", true));
            this.goldTextBox.Location = new System.Drawing.Point(277, 43);
            this.goldTextBox.Name = "goldTextBox";
            this.goldTextBox.Size = new System.Drawing.Size(100, 22);
            this.goldTextBox.TabIndex = 3;
            // 
            // silverLabel
            // 
            silverLabel.AutoSize = true;
            silverLabel.Location = new System.Drawing.Point(101, 74);
            silverLabel.Name = "silverLabel";
            silverLabel.Size = new System.Drawing.Size(47, 17);
            silverLabel.TabIndex = 4;
            silverLabel.Text = "Silver:";
            // 
            // silverTextBox
            // 
            this.silverTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Silver", true));
            this.silverTextBox.Location = new System.Drawing.Point(277, 71);
            this.silverTextBox.Name = "silverTextBox";
            this.silverTextBox.Size = new System.Drawing.Size(100, 22);
            this.silverTextBox.TabIndex = 5;
            // 
            // platinumLabel
            // 
            platinumLabel.AutoSize = true;
            platinumLabel.Location = new System.Drawing.Point(101, 102);
            platinumLabel.Name = "platinumLabel";
            platinumLabel.Size = new System.Drawing.Size(66, 17);
            platinumLabel.TabIndex = 6;
            platinumLabel.Text = "Platinum:";
            // 
            // platinumTextBox
            // 
            this.platinumTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Platinum", true));
            this.platinumTextBox.Location = new System.Drawing.Point(277, 99);
            this.platinumTextBox.Name = "platinumTextBox";
            this.platinumTextBox.Size = new System.Drawing.Size(100, 22);
            this.platinumTextBox.TabIndex = 7;
            // 
            // platiumGroupMetalLabel
            // 
            platiumGroupMetalLabel.AutoSize = true;
            platiumGroupMetalLabel.Location = new System.Drawing.Point(101, 134);
            platiumGroupMetalLabel.Name = "platiumGroupMetalLabel";
            platiumGroupMetalLabel.Size = new System.Drawing.Size(140, 17);
            platiumGroupMetalLabel.TabIndex = 8;
            platiumGroupMetalLabel.Text = "Platium Group Metal:";
            // 
            // platiumGroupMetalTextBox
            // 
            this.platiumGroupMetalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "PlatiumGroupMetal", true));
            this.platiumGroupMetalTextBox.Location = new System.Drawing.Point(277, 131);
            this.platiumGroupMetalTextBox.Name = "platiumGroupMetalTextBox";
            this.platiumGroupMetalTextBox.Size = new System.Drawing.Size(100, 22);
            this.platiumGroupMetalTextBox.TabIndex = 9;
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(417, 16);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(65, 17);
            quantityLabel.TabIndex = 10;
            quantityLabel.Text = "Quantity:";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(593, 13);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(100, 22);
            this.quantityTextBox.TabIndex = 11;
            // 
            // surnameLabel
            // 
            surnameLabel.AutoSize = true;
            surnameLabel.Location = new System.Drawing.Point(417, 44);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new System.Drawing.Size(69, 17);
            surnameLabel.TabIndex = 12;
            surnameLabel.Text = "Surname:";
            // 
            // surnameTextBox
            // 
            this.surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Surname", true));
            this.surnameTextBox.Location = new System.Drawing.Point(593, 41);
            this.surnameTextBox.Name = "surnameTextBox";
            this.surnameTextBox.Size = new System.Drawing.Size(100, 22);
            this.surnameTextBox.TabIndex = 13;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(417, 72);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(49, 17);
            nameLabel.TabIndex = 14;
            nameLabel.Text = "Name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(593, 69);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 22);
            this.nameTextBox.TabIndex = 15;
            // 
            // patronimicLabel
            // 
            patronimicLabel.AutoSize = true;
            patronimicLabel.Location = new System.Drawing.Point(417, 100);
            patronimicLabel.Name = "patronimicLabel";
            patronimicLabel.Size = new System.Drawing.Size(78, 17);
            patronimicLabel.TabIndex = 16;
            patronimicLabel.Text = "Patronimic:";
            // 
            // patronimicTextBox
            // 
            this.patronimicTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.balance_FixedAssets_MOLBindingSource, "Patronimic", true));
            this.patronimicTextBox.Location = new System.Drawing.Point(593, 97);
            this.patronimicTextBox.Name = "patronimicTextBox";
            this.patronimicTextBox.Size = new System.Drawing.Size(100, 22);
            this.patronimicTextBox.TabIndex = 17;
            // 
            // View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 549);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.balance_FixedAssets_MOLDataGridView);
            this.Controls.Add(this.balance_FixedAssets_MOLBindingNavigator);
            this.Name = "View";
            this.Text = "View";
            this.Load += new System.EventHandler(this.View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.view1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance_FixedAssets_MOLBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.balance_FixedAssets_MOLBindingNavigator)).EndInit();
            this.balance_FixedAssets_MOLBindingNavigator.ResumeLayout(false);
            this.balance_FixedAssets_MOLBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.balance_FixedAssets_MOLDataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Dataset.View view1;
        private System.Windows.Forms.BindingSource balance_FixedAssets_MOLBindingSource;
        private Dataset.ViewTableAdapters.Balance_FixedAssets_MOLTableAdapter balance_FixedAssets_MOLTableAdapter;
        private Dataset.ViewTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator balance_FixedAssets_MOLBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView balance_FixedAssets_MOLDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox designationFixedAssetsTextBox;
        private System.Windows.Forms.TextBox goldTextBox;
        private System.Windows.Forms.TextBox silverTextBox;
        private System.Windows.Forms.TextBox platinumTextBox;
        private System.Windows.Forms.TextBox platiumGroupMetalTextBox;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.TextBox surnameTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox patronimicTextBox;
    }
}
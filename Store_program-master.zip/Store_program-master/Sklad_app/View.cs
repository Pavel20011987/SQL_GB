﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class View : Form
    {
        public View()
        {
            InitializeComponent();
        }

        private void View_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "view1.Balance_FixedAssets_MOL". При необходимости она может быть перемещена или удалена.
            this.balance_FixedAssets_MOLTableAdapter.Fill(this.view1.Balance_FixedAssets_MOL);

        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            new_edit_del_butt_controler();
            this.balance_FixedAssets_MOLBindingSource.AddNew();
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            new_edit_del_butt_controler();
            //----------------------------------
            Int32 rc;
            rc = this.view1.Balance_FixedAssets_MOL.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Please select your record to edit!");
                return;
            }
            //---------------------------------------

        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            new_edit_del_butt_controler();
            //---------------------------------
            Int32 rc;
            rc = this.view1.Balance_FixedAssets_MOL.Rows.Count;
            if (rc == 0)
            {
                MessageBox.Show("Please select your record to delete!");
                return;
            }
            //---------------------------------------
            new_edit_del_butt_controler();
            this.balance_FixedAssets_MOLBindingSource.RemoveCurrent();
            //-----------------------------------------
            this.groupBox1.Enabled = false;
        }
        void new_edit_del_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = false;
            this.Edit_butt.Enabled = false;
            this.Del_butt.Enabled = false;
            //------------------------------------
            this.save_butt.Enabled = true;
            this.cancel_butt.Enabled = true;
            //------------------------------------
            this.groupBox1.Enabled = true;
            this.balance_FixedAssets_MOLDataGridView.Enabled = false;
            this.balance_FixedAssets_MOLBindingNavigator.Enabled = false;
            //-------------------------------------
        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            this.Validate();
            this.balance_FixedAssets_MOLBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.balance_FixedAssets_MOLTableAdapter.Update(this.view1.Balance_FixedAssets_MOL);
            if (r > 0)
            {
                MessageBox.Show("Done! Count: " + r.ToString());
            }
            else
            {
                MessageBox.Show("Nothing Saved! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            save_cancel_butt_controler();
            
            this.balance_FixedAssets_MOLBindingSource.CancelEdit();
            this.view1.Balance_FixedAssets_MOL.RejectChanges();
        }
        void save_cancel_butt_controler()
        {
            //-----------------------------------
            this.Add_butt.Enabled = true;
            this.Edit_butt.Enabled = true;
            this.Del_butt.Enabled = true;
            //------------------------------------
            this.save_butt.Enabled = false;
            this.cancel_butt.Enabled = false;
            //------------------------------------
            this.groupBox1.Enabled = false;
            this.balance_FixedAssets_MOLDataGridView.Enabled = true;
            this.balance_FixedAssets_MOLBindingNavigator.Enabled = true;
            //------------------------------------
        }

    }
}

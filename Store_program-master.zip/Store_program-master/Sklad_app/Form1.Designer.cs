﻿
namespace Sklad_app
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.формыВПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.расходДрагметалловНаСкладеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.приходОсновныхСредствНаСкладToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.основныеСредстваНаСкладеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.журналУчетаДрагметалловНаСкладеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.формыВПрограммеToolStripMenuItem,
            this.отчетыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(843, 28);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // формыВПрограммеToolStripMenuItem
            // 
            this.формыВПрограммеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.расходДрагметалловНаСкладеToolStripMenuItem,
            this.приходОсновныхСредствНаСкладToolStripMenuItem,
            this.основныеСредстваНаСкладеToolStripMenuItem,
            this.журналУчетаДрагметалловНаСкладеToolStripMenuItem});
            this.формыВПрограммеToolStripMenuItem.Name = "формыВПрограммеToolStripMenuItem";
            this.формыВПрограммеToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.формыВПрограммеToolStripMenuItem.Text = "Формы в программе";
            // 
            // расходДрагметалловНаСкладеToolStripMenuItem
            // 
            this.расходДрагметалловНаСкладеToolStripMenuItem.Name = "расходДрагметалловНаСкладеToolStripMenuItem";
            this.расходДрагметалловНаСкладеToolStripMenuItem.Size = new System.Drawing.Size(345, 24);
            this.расходДрагметалловНаСкладеToolStripMenuItem.Text = "Расход драгметаллов на складе";
            this.расходДрагметалловНаСкладеToolStripMenuItem.Click += new System.EventHandler(this.расходДрагметалловНаСкладеToolStripMenuItem_Click);
            // 
            // приходОсновныхСредствНаСкладToolStripMenuItem
            // 
            this.приходОсновныхСредствНаСкладToolStripMenuItem.Name = "приходОсновныхСредствНаСкладToolStripMenuItem";
            this.приходОсновныхСредствНаСкладToolStripMenuItem.Size = new System.Drawing.Size(345, 24);
            this.приходОсновныхСредствНаСкладToolStripMenuItem.Text = "Приход основных средств на склад";
            this.приходОсновныхСредствНаСкладToolStripMenuItem.Click += new System.EventHandler(this.приходОсновныхСредствНаСкладToolStripMenuItem_Click);
            // 
            // основныеСредстваНаСкладеToolStripMenuItem
            // 
            this.основныеСредстваНаСкладеToolStripMenuItem.Name = "основныеСредстваНаСкладеToolStripMenuItem";
            this.основныеСредстваНаСкладеToolStripMenuItem.Size = new System.Drawing.Size(345, 24);
            this.основныеСредстваНаСкладеToolStripMenuItem.Text = "Основные средства на складе";
            this.основныеСредстваНаСкладеToolStripMenuItem.Click += new System.EventHandler(this.основныеСредстваНаСкладеToolStripMenuItem_Click);
            // 
            // журналУчетаДрагметалловНаСкладеToolStripMenuItem
            // 
            this.журналУчетаДрагметалловНаСкладеToolStripMenuItem.Name = "журналУчетаДрагметалловНаСкладеToolStripMenuItem";
            this.журналУчетаДрагметалловНаСкладеToolStripMenuItem.Size = new System.Drawing.Size(345, 24);
            this.журналУчетаДрагметалловНаСкладеToolStripMenuItem.Text = "Журнал учета драгметаллов на складе";
            this.журналУчетаДрагметалловНаСкладеToolStripMenuItem.Click += new System.EventHandler(this.журналУчетаДрагметалловНаСкладеToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem,
            this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem,
            this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem
            // 
            this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem.Name = "отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem";
            this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem.Size = new System.Drawing.Size(418, 24);
            this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem.Text = "Отчет об остатках на отчетную дату";
            this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem.Click += new System.EventHandler(this.отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem_Click);
            // 
            // описьОПередачеДрагметалловВЛабораториюToolStripMenuItem
            // 
            this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem.Name = "описьОПередачеДрагметалловВЛабораториюToolStripMenuItem";
            this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem.Size = new System.Drawing.Size(418, 24);
            this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem.Text = "Опись о передаче драгметаллов в лабораторию";
            this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem.Click += new System.EventHandler(this.описьОПередачеДрагметалловВЛабораториюToolStripMenuItem_Click);
            // 
            // журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem
            // 
            this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem.Name = "журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem";
            this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem.Size = new System.Drawing.Size(418, 24);
            this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem.Text = "Журнал учета передачи драгметаллов на складе";
            this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem.Click += new System.EventHandler(this.журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::Sklad_app.Properties.Resources.Фон;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(843, 685);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Основная форма";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem формыВПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem расходДрагметалловНаСкладеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem приходОсновныхСредствНаСкладToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem основныеСредстваНаСкладеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem журналУчетаДрагметалловНаСкладеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem описьОПередачеДрагметалловВЛабораториюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem;
    }
}


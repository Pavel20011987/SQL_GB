﻿namespace Sklad_app
{
    partial class Report3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.workTime_skDataSet4 = new Sklad_app.WorkTime_skDataSet4();
            this.outviewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.out_viewTableAdapter = new Sklad_app.WorkTime_skDataSet4TableAdapters.Out_viewTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.workTime_skDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.outviewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.outviewBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sklad_app.Report3.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(54, 39);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(710, 364);
            this.reportViewer1.TabIndex = 0;
            // 
            // workTime_skDataSet4
            // 
            this.workTime_skDataSet4.DataSetName = "WorkTime_skDataSet4";
            this.workTime_skDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // outviewBindingSource
            // 
            this.outviewBindingSource.DataMember = "Out_view";
            this.outviewBindingSource.DataSource = this.workTime_skDataSet4;
            // 
            // out_viewTableAdapter
            // 
            this.out_viewTableAdapter.ClearBeforeFill = true;
            // 
            // Report3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 460);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Report3";
            this.Text = "Report3";
            this.Load += new System.EventHandler(this.Report3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.workTime_skDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.outviewBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private WorkTime_skDataSet4 workTime_skDataSet4;
        private System.Windows.Forms.BindingSource outviewBindingSource;
        private WorkTime_skDataSet4TableAdapters.Out_viewTableAdapter out_viewTableAdapter;
    }
}
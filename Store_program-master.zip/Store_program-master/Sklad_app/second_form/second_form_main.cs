﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.second_form
{
    public partial class FixedAssets : Form
    {
        public FixedAssets()
        {
            InitializeComponent();
        }

        private void second_form_main_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "fixedAssets1._FixedAssets". При необходимости она может быть перемещена или удалена.
            this.fixedAssetsTableAdapter.Fill(this.fixedAssets1._FixedAssets);

        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.second_form.second_form_child frm = new second_form_child();
            frm.st_lb.Text = "Новое значение";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult==DialogResult.OK)
            {
                this.fixedAssetsTableAdapter.Fill(this.fixedAssets1._FixedAssets);
            }
            
            //-----------------------------------------
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            Int32 rn;
            rn = this.fixedAssets1._FixedAssets.Rows.Count;
            if (rn==0)
            {
                MessageBox.Show("Please select your record to edit!");
                return;
            }
            Sklad_app.second_form.second_form_child frm = new second_form_child();
            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idFixedAssetsLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.st_lb.Text = "Значение для редактирования";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.fixedAssetsTableAdapter.Fill(this.fixedAssets1._FixedAssets);
            }

            //-----------------------------------------
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.second_form.second_form_child frm = new second_form_child();
            
            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idFixedAssetsLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.Sel_id_lb.Text = this.idFixedAssetsLabel1.Text;
            frm.st_lb.Text = "Значение для удаления";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.fixedAssetsTableAdapter.Fill(this.fixedAssets1._FixedAssets);
            }

            //-----------------------------------------
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.fixedAssetsTableAdapter.Fill(this.fixedAssets1._FixedAssets);
        }
    }
}

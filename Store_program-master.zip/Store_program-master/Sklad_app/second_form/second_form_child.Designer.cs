﻿
namespace Sklad_app.second_form
{
    partial class second_form_child
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idFixedAssetsLabel;
            System.Windows.Forms.Label designationFixedAssetsLabel;
            System.Windows.Forms.Label idMateriallyResponsiblePersonLabel;
            System.Windows.Forms.Label goldLabel;
            System.Windows.Forms.Label silverLabel;
            System.Windows.Forms.Label platinumLabel;
            System.Windows.Forms.Label platiumGroupMetalLabel;
            System.Windows.Forms.Label label1;
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.fixedAssetsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fixedAssets = new Sklad_app.Dataset.FixedAssets();
            this.designationFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.idMateriallyResponsiblePersonTextBox = new System.Windows.Forms.TextBox();
            this.goldTextBox = new System.Windows.Forms.TextBox();
            this.silverTextBox = new System.Windows.Forms.TextBox();
            this.platinumTextBox = new System.Windows.Forms.TextBox();
            this.platiumGroupMetalTextBox = new System.Windows.Forms.TextBox();
            this.fixedAssetsTableAdapter = new Sklad_app.Dataset.FixedAssetsTableAdapters.FixedAssetsTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.FixedAssetsTableAdapters.TableAdapterManager();
            this.panel2 = new System.Windows.Forms.Panel();
            this.st_lb = new System.Windows.Forms.Label();
            this.Sel_id_lb = new System.Windows.Forms.Label();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.Add_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            idFixedAssetsLabel = new System.Windows.Forms.Label();
            designationFixedAssetsLabel = new System.Windows.Forms.Label();
            idMateriallyResponsiblePersonLabel = new System.Windows.Forms.Label();
            goldLabel = new System.Windows.Forms.Label();
            silverLabel = new System.Windows.Forms.Label();
            platinumLabel = new System.Windows.Forms.Label();
            platiumGroupMetalLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fixedAssetsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedAssets)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // idFixedAssetsLabel
            // 
            idFixedAssetsLabel.AutoSize = true;
            idFixedAssetsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            idFixedAssetsLabel.Location = new System.Drawing.Point(35, 94);
            idFixedAssetsLabel.Name = "idFixedAssetsLabel";
            idFixedAssetsLabel.Size = new System.Drawing.Size(77, 20);
            idFixedAssetsLabel.TabIndex = 0;
            idFixedAssetsLabel.Text = "Код ОС:";
            // 
            // designationFixedAssetsLabel
            // 
            designationFixedAssetsLabel.AutoSize = true;
            designationFixedAssetsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            designationFixedAssetsLabel.Location = new System.Drawing.Point(35, 124);
            designationFixedAssetsLabel.Name = "designationFixedAssetsLabel";
            designationFixedAssetsLabel.Size = new System.Drawing.Size(169, 20);
            designationFixedAssetsLabel.TabIndex = 2;
            designationFixedAssetsLabel.Text = "Наименование ОС:";
            // 
            // idMateriallyResponsiblePersonLabel
            // 
            idMateriallyResponsiblePersonLabel.AutoSize = true;
            idMateriallyResponsiblePersonLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            idMateriallyResponsiblePersonLabel.Location = new System.Drawing.Point(35, 154);
            idMateriallyResponsiblePersonLabel.Name = "idMateriallyResponsiblePersonLabel";
            idMateriallyResponsiblePersonLabel.Size = new System.Drawing.Size(91, 20);
            idMateriallyResponsiblePersonLabel.TabIndex = 4;
            idMateriallyResponsiblePersonLabel.Text = "Код МОЛ:";
            // 
            // goldLabel
            // 
            goldLabel.AutoSize = true;
            goldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            goldLabel.Location = new System.Drawing.Point(35, 184);
            goldLabel.Name = "goldLabel";
            goldLabel.Size = new System.Drawing.Size(76, 20);
            goldLabel.TabIndex = 6;
            goldLabel.Text = "Золото:";
            // 
            // silverLabel
            // 
            silverLabel.AutoSize = true;
            silverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            silverLabel.Location = new System.Drawing.Point(35, 214);
            silverLabel.Name = "silverLabel";
            silverLabel.Size = new System.Drawing.Size(86, 20);
            silverLabel.TabIndex = 8;
            silverLabel.Text = "Серебро:";
            // 
            // platinumLabel
            // 
            platinumLabel.AutoSize = true;
            platinumLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            platinumLabel.Location = new System.Drawing.Point(35, 244);
            platinumLabel.Name = "platinumLabel";
            platinumLabel.Size = new System.Drawing.Size(87, 20);
            platinumLabel.TabIndex = 10;
            platinumLabel.Text = "Платина:";
            // 
            // platiumGroupMetalLabel
            // 
            platiumGroupMetalLabel.AutoSize = true;
            platiumGroupMetalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            platiumGroupMetalLabel.Location = new System.Drawing.Point(35, 274);
            platiumGroupMetalLabel.Name = "platiumGroupMetalLabel";
            platiumGroupMetalLabel.Size = new System.Drawing.Size(265, 20);
            platiumGroupMetalLabel.TabIndex = 12;
            platiumGroupMetalLabel.Text = "Платиновая группа металлов:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label1.Location = new System.Drawing.Point(15, 16);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(73, 20);
            label1.TabIndex = 3;
            label1.Text = "Статус:";
            label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Location = new System.Drawing.Point(2, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(481, 87);
            this.panel1.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(idFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.idFixedAssetsTextBox);
            this.groupBox1.Controls.Add(designationFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.designationFixedAssetsTextBox);
            this.groupBox1.Controls.Add(idMateriallyResponsiblePersonLabel);
            this.groupBox1.Controls.Add(this.idMateriallyResponsiblePersonTextBox);
            this.groupBox1.Controls.Add(goldLabel);
            this.groupBox1.Controls.Add(this.goldTextBox);
            this.groupBox1.Controls.Add(silverLabel);
            this.groupBox1.Controls.Add(this.silverTextBox);
            this.groupBox1.Controls.Add(platinumLabel);
            this.groupBox1.Controls.Add(this.platinumTextBox);
            this.groupBox1.Controls.Add(platiumGroupMetalLabel);
            this.groupBox1.Controls.Add(this.platiumGroupMetalTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 116);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(471, 327);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация";
            // 
            // idFixedAssetsTextBox
            // 
            this.idFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "idFixedAssets", true));
            this.idFixedAssetsTextBox.Location = new System.Drawing.Point(322, 90);
            this.idFixedAssetsTextBox.Name = "idFixedAssetsTextBox";
            this.idFixedAssetsTextBox.ReadOnly = true;
            this.idFixedAssetsTextBox.Size = new System.Drawing.Size(100, 24);
            this.idFixedAssetsTextBox.TabIndex = 1;
            // 
            // fixedAssetsBindingSource
            // 
            this.fixedAssetsBindingSource.DataMember = "FixedAssets";
            this.fixedAssetsBindingSource.DataSource = this.fixedAssets;
            // 
            // fixedAssets
            // 
            this.fixedAssets.DataSetName = "FixedAssets";
            this.fixedAssets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // designationFixedAssetsTextBox
            // 
            this.designationFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "DesignationFixedAssets", true));
            this.designationFixedAssetsTextBox.Location = new System.Drawing.Point(322, 120);
            this.designationFixedAssetsTextBox.Name = "designationFixedAssetsTextBox";
            this.designationFixedAssetsTextBox.Size = new System.Drawing.Size(100, 24);
            this.designationFixedAssetsTextBox.TabIndex = 3;
            // 
            // idMateriallyResponsiblePersonTextBox
            // 
            this.idMateriallyResponsiblePersonTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "idMateriallyResponsiblePerson", true));
            this.idMateriallyResponsiblePersonTextBox.Location = new System.Drawing.Point(322, 150);
            this.idMateriallyResponsiblePersonTextBox.Name = "idMateriallyResponsiblePersonTextBox";
            this.idMateriallyResponsiblePersonTextBox.Size = new System.Drawing.Size(100, 24);
            this.idMateriallyResponsiblePersonTextBox.TabIndex = 5;
            // 
            // goldTextBox
            // 
            this.goldTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "Gold", true));
            this.goldTextBox.Location = new System.Drawing.Point(322, 180);
            this.goldTextBox.Name = "goldTextBox";
            this.goldTextBox.Size = new System.Drawing.Size(100, 24);
            this.goldTextBox.TabIndex = 7;
            // 
            // silverTextBox
            // 
            this.silverTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "Silver", true));
            this.silverTextBox.Location = new System.Drawing.Point(322, 210);
            this.silverTextBox.Name = "silverTextBox";
            this.silverTextBox.Size = new System.Drawing.Size(100, 24);
            this.silverTextBox.TabIndex = 9;
            // 
            // platinumTextBox
            // 
            this.platinumTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "Platinum", true));
            this.platinumTextBox.Location = new System.Drawing.Point(322, 240);
            this.platinumTextBox.Name = "platinumTextBox";
            this.platinumTextBox.Size = new System.Drawing.Size(100, 24);
            this.platinumTextBox.TabIndex = 11;
            // 
            // platiumGroupMetalTextBox
            // 
            this.platiumGroupMetalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedAssetsBindingSource, "PlatiumGroupMetal", true));
            this.platiumGroupMetalTextBox.Location = new System.Drawing.Point(322, 270);
            this.platiumGroupMetalTextBox.Name = "platiumGroupMetalTextBox";
            this.platiumGroupMetalTextBox.Size = new System.Drawing.Size(100, 24);
            this.platiumGroupMetalTextBox.TabIndex = 13;
            // 
            // fixedAssetsTableAdapter
            // 
            this.fixedAssetsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FixedAssetsTableAdapter = this.fixedAssetsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.FixedAssetsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.st_lb);
            this.panel2.Controls.Add(label1);
            this.panel2.Location = new System.Drawing.Point(12, 449);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(469, 71);
            this.panel2.TabIndex = 8;
            // 
            // st_lb
            // 
            this.st_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.st_lb.ForeColor = System.Drawing.Color.Maroon;
            this.st_lb.Location = new System.Drawing.Point(94, 16);
            this.st_lb.Name = "st_lb";
            this.st_lb.Size = new System.Drawing.Size(357, 20);
            this.st_lb.TabIndex = 4;
            this.st_lb.Text = "-";
            this.st_lb.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.st_lb.Click += new System.EventHandler(this.st_lb_Click);
            // 
            // Sel_id_lb
            // 
            this.Sel_id_lb.AutoSize = true;
            this.Sel_id_lb.Location = new System.Drawing.Point(555, 296);
            this.Sel_id_lb.Name = "Sel_id_lb";
            this.Sel_id_lb.Size = new System.Drawing.Size(42, 18);
            this.Sel_id_lb.TabIndex = 14;
            this.Sel_id_lb.Text = "sel id";
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(171, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(10, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(746, 228);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(109, 71);
            this.Add_butt.TabIndex = 0;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(1034, 228);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 2;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(863, 228);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 1;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            // 
            // second_form_child
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(505, 533);
            this.Controls.Add(this.Sel_id_lb);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Add_butt);
            this.Controls.Add(this.Del_butt);
            this.Controls.Add(this.Edit_butt);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "second_form_child";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "second_form_child";
            this.Load += new System.EventHandler(this.second_form_child_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fixedAssetsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedAssets)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.GroupBox groupBox1;
        private Dataset.FixedAssets fixedAssets;
        private System.Windows.Forms.BindingSource fixedAssetsBindingSource;
        private Dataset.FixedAssetsTableAdapters.FixedAssetsTableAdapter fixedAssetsTableAdapter;
        private Dataset.FixedAssetsTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox idFixedAssetsTextBox;
        private System.Windows.Forms.TextBox designationFixedAssetsTextBox;
        private System.Windows.Forms.TextBox idMateriallyResponsiblePersonTextBox;
        private System.Windows.Forms.TextBox goldTextBox;
        private System.Windows.Forms.TextBox silverTextBox;
        private System.Windows.Forms.TextBox platinumTextBox;
        private System.Windows.Forms.TextBox platiumGroupMetalTextBox;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label st_lb;
        public System.Windows.Forms.Label Sel_id_lb;
    }
}
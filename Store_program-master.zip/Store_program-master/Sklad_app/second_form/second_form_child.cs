﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.second_form
{
    public partial class second_form_child : Form
    {
        public second_form_child()
        {
            InitializeComponent();
        }

       

        private void second_form_child_Load(object sender, EventArgs e)
        {
            if (this.st_lb.Text== "Новое значение")
            {
                this.fixedAssetsBindingSource.AddNew();
                this.groupBox1.Enabled = true;
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для редактирования")
            {
                this.groupBox1.Enabled = true;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.fixedAssetsTableAdapter.FillBy_id(this.fixedAssets._FixedAssets, (int)i);
                //------------------------------------------------
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.groupBox1.Enabled = false;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.fixedAssetsTableAdapter.FillBy_id(this.fixedAssets._FixedAssets, (int)i);
                //------------------------------------------------
            }

        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.fixedAssetsBindingSource.RemoveCurrent();
            }
           
            this.Validate();
            this.fixedAssetsBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.fixedAssetsTableAdapter.Update(this.fixedAssets._FixedAssets);
            if (r > 0)
            {
                MessageBox.Show("Done! Count: " + r.ToString());
                // this.Close();
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Nothing Saved! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            // this.Close();
            this.DialogResult = DialogResult.Cancel;
        }

        private void st_lb_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

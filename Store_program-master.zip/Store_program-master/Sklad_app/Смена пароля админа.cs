﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Sklad_app
{
    public partial class Смена_пароля_админа : Form
    {
        public Смена_пароля_админа()
        {
            InitializeComponent();
        }
        public int kod;

        private void button1_Click(object sender, EventArgs e)
        {
             if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("Вы не ввели старый пароль!");
            }
            else if (label3.Text.Trim() != textBox1.Text.Trim())
            {
                MessageBox.Show("Вы ввели неверно старый пароль!");
            }
            else if (textBox2.Text.Trim() == "")
            {
                MessageBox.Show("Вы не ввели новый пароль!");
            }
            else
            {
                DialogResult result = MessageBox.Show("Вы действительно хотите сменить пароль?", "Планировщик", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    string connStr = @"Data Source=HOME-PC;Initial Catalog=WorkTime_sk;Integrated Security=True";
                    using (SqlConnection cn = new SqlConnection(connStr))
                    {
                        cn.Open();
                        using (SqlCommand command = cn.CreateCommand())
                        {
                            command.CommandText = "update Users set Password = @pass where KodUser = @kod";
                            command.Parameters.Add(new SqlParameter("@pass", textBox2.Text));
                            command.Parameters.Add(new SqlParameter("@kod", kod));
                            command.ExecuteNonQuery();
                            MessageBox.Show("Данные сохранены! Программа будет перезапущена.");
                            cn.Close();
                            Application.Restart();
                        }

                    }

                }
            }
        }
    

        private void Смена_пароля_админа_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "смена_пароля.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter.Fill(this.смена_пароля.Users);
            usersBindingSource.Filter = "KodUser = " + Convert.ToString(kod);
           
        }

        private void usersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.usersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.смена_пароля);

        }
    }
}

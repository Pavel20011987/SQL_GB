﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Sklad_app
{
    public partial class Report2 : Form
    {
        public Report2()
        {
            InitializeComponent();
        }
        public int stat;
        public string dat1, dat2;

        private void Report2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "workTime_skDataSet2.Fixed". При необходимости она может быть перемещена или удалена.
            this.fixedTableAdapter.FillBy(this.workTime_skDataSet2.Fixed, @dat1, @dat2);
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "workTime_skDataSet21.Fixed". При необходимости она может быть перемещена или удалена.
           
            

            // TODO: данная строка кода позволяет загрузить данные в таблицу "WorkTime_skDataSet.Bal_view". При необходимости она может быть перемещена или удалена.
           // this.Bal_viewTableAdapter.Fill(this.WorkTime_skDataSet.Bal_view);
            if (stat == 1)
            {
                reportViewer1.Visible = true;
                reportViewer1.Dock = DockStyle.Fill;
                this.fixedTableAdapter.FillBy(this.workTime_skDataSet2.Fixed, @dat1, @dat2);
                //Sklad_app.WorkTime_skDataSet2TableAdapters.FixedTableAdapter.FillBy()
                this.reportViewer1.RefreshReport();
            }
        }
    }
}

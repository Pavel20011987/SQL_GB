﻿
namespace Sklad_app
{
    partial class Inflows_view
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idInflowsLabel;
            System.Windows.Forms.Label idFixedAssetsLabel;
            System.Windows.Forms.Label designationFixedAssetsLabel;
            System.Windows.Forms.Label mAC_FALabel;
            System.Windows.Forms.Label idMateriallyResponsiblePersonLabel;
            System.Windows.Forms.Label surnameLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label patronimicLabel;
            System.Windows.Forms.Label deliveryDateLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inflows_view));
            this.panel1 = new System.Windows.Forms.Panel();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.Add_butt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idInflowsTextBox = new System.Windows.Forms.TextBox();
            this.inflows_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inflows_view1 = new Sklad_app.Dataset.Inflows_view();
            this.idFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.designationFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.mAC_FATextBox = new System.Windows.Forms.TextBox();
            this.idMateriallyResponsiblePersonTextBox = new System.Windows.Forms.TextBox();
            this.surnameTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.patronimicTextBox = new System.Windows.Forms.TextBox();
            this.deliveryDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.inflows_viewTableAdapter = new Sklad_app.Dataset.Inflows_viewTableAdapters.Inflows_viewTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.Inflows_viewTableAdapters.TableAdapterManager();
            this.inflows_viewBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.inflows_viewDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            idInflowsLabel = new System.Windows.Forms.Label();
            idFixedAssetsLabel = new System.Windows.Forms.Label();
            designationFixedAssetsLabel = new System.Windows.Forms.Label();
            mAC_FALabel = new System.Windows.Forms.Label();
            idMateriallyResponsiblePersonLabel = new System.Windows.Forms.Label();
            surnameLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            patronimicLabel = new System.Windows.Forms.Label();
            deliveryDateLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_view1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_viewBindingNavigator)).BeginInit();
            this.inflows_viewBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_viewDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idInflowsLabel
            // 
            idInflowsLabel.AutoSize = true;
            idInflowsLabel.Location = new System.Drawing.Point(55, 29);
            idInflowsLabel.Name = "idInflowsLabel";
            idInflowsLabel.Size = new System.Drawing.Size(95, 17);
            idInflowsLabel.TabIndex = 0;
            idInflowsLabel.Text = "Код прихода:";
            // 
            // idFixedAssetsLabel
            // 
            idFixedAssetsLabel.AutoSize = true;
            idFixedAssetsLabel.Location = new System.Drawing.Point(55, 57);
            idFixedAssetsLabel.Name = "idFixedAssetsLabel";
            idFixedAssetsLabel.Size = new System.Drawing.Size(61, 17);
            idFixedAssetsLabel.TabIndex = 2;
            idFixedAssetsLabel.Text = "Код ОС:";
            // 
            // designationFixedAssetsLabel
            // 
            designationFixedAssetsLabel.AutoSize = true;
            designationFixedAssetsLabel.Location = new System.Drawing.Point(55, 85);
            designationFixedAssetsLabel.Name = "designationFixedAssetsLabel";
            designationFixedAssetsLabel.Size = new System.Drawing.Size(134, 17);
            designationFixedAssetsLabel.TabIndex = 4;
            designationFixedAssetsLabel.Text = "Наименование ОС:";
            // 
            // mAC_FALabel
            // 
            mAC_FALabel.AutoSize = true;
            mAC_FALabel.Location = new System.Drawing.Point(55, 113);
            mAC_FALabel.Name = "mAC_FALabel";
            mAC_FALabel.Size = new System.Drawing.Size(171, 17);
            mAC_FALabel.TabIndex = 6;
            mAC_FALabel.Text = "Инвентарный номер ОС:";
            // 
            // idMateriallyResponsiblePersonLabel
            // 
            idMateriallyResponsiblePersonLabel.AutoSize = true;
            idMateriallyResponsiblePersonLabel.Location = new System.Drawing.Point(55, 141);
            idMateriallyResponsiblePersonLabel.Name = "idMateriallyResponsiblePersonLabel";
            idMateriallyResponsiblePersonLabel.Size = new System.Drawing.Size(73, 17);
            idMateriallyResponsiblePersonLabel.TabIndex = 8;
            idMateriallyResponsiblePersonLabel.Text = "Код МОЛ:";
            // 
            // surnameLabel
            // 
            surnameLabel.AutoSize = true;
            surnameLabel.Location = new System.Drawing.Point(55, 169);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new System.Drawing.Size(74, 17);
            surnameLabel.TabIndex = 10;
            surnameLabel.Text = "Фамилия:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(55, 197);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(39, 17);
            nameLabel.TabIndex = 12;
            nameLabel.Text = "Имя:";
            // 
            // patronimicLabel
            // 
            patronimicLabel.AutoSize = true;
            patronimicLabel.Location = new System.Drawing.Point(488, 27);
            patronimicLabel.Name = "patronimicLabel";
            patronimicLabel.Size = new System.Drawing.Size(75, 17);
            patronimicLabel.TabIndex = 14;
            patronimicLabel.Text = "Отчество:";
            // 
            // deliveryDateLabel
            // 
            deliveryDateLabel.AutoSize = true;
            deliveryDateLabel.Location = new System.Drawing.Point(488, 56);
            deliveryDateLabel.Name = "deliveryDateLabel";
            deliveryDateLabel.Size = new System.Drawing.Size(159, 17);
            deliveryDateLabel.TabIndex = 16;
            deliveryDateLabel.Text = "Дата поступления ОС:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Controls.Add(this.Del_butt);
            this.panel1.Controls.Add(this.Edit_butt);
            this.panel1.Controls.Add(this.Add_butt);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(854, 87);
            this.panel1.TabIndex = 7;
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(594, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(455, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(329, 4);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 2;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            this.Del_butt.Click += new System.EventHandler(this.Del_butt_Click);
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(160, 4);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 1;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            this.Edit_butt.Click += new System.EventHandler(this.Edit_butt_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(16, 4);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(134, 71);
            this.Add_butt.TabIndex = 0;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            this.Add_butt.Click += new System.EventHandler(this.Add_butt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(idInflowsLabel);
            this.groupBox1.Controls.Add(this.idInflowsTextBox);
            this.groupBox1.Controls.Add(idFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.idFixedAssetsTextBox);
            this.groupBox1.Controls.Add(designationFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.designationFixedAssetsTextBox);
            this.groupBox1.Controls.Add(mAC_FALabel);
            this.groupBox1.Controls.Add(this.mAC_FATextBox);
            this.groupBox1.Controls.Add(idMateriallyResponsiblePersonLabel);
            this.groupBox1.Controls.Add(this.idMateriallyResponsiblePersonTextBox);
            this.groupBox1.Controls.Add(surnameLabel);
            this.groupBox1.Controls.Add(this.surnameTextBox);
            this.groupBox1.Controls.Add(nameLabel);
            this.groupBox1.Controls.Add(this.nameTextBox);
            this.groupBox1.Controls.Add(patronimicLabel);
            this.groupBox1.Controls.Add(this.patronimicTextBox);
            this.groupBox1.Controls.Add(deliveryDateLabel);
            this.groupBox1.Controls.Add(this.deliveryDateDateTimePicker);
            this.groupBox1.Location = new System.Drawing.Point(13, 108);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(870, 229);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация";
            // 
            // idInflowsTextBox
            // 
            this.idInflowsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "idInflows", true));
            this.idInflowsTextBox.Location = new System.Drawing.Point(279, 26);
            this.idInflowsTextBox.Name = "idInflowsTextBox";
            this.idInflowsTextBox.Size = new System.Drawing.Size(200, 22);
            this.idInflowsTextBox.TabIndex = 1;
            // 
            // inflows_viewBindingSource
            // 
            this.inflows_viewBindingSource.DataMember = "Inflows_view";
            this.inflows_viewBindingSource.DataSource = this.inflows_view1;
            // 
            // inflows_view1
            // 
            this.inflows_view1.DataSetName = "Inflows_view";
            this.inflows_view1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // idFixedAssetsTextBox
            // 
            this.idFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "idFixedAssets", true));
            this.idFixedAssetsTextBox.Location = new System.Drawing.Point(279, 54);
            this.idFixedAssetsTextBox.Name = "idFixedAssetsTextBox";
            this.idFixedAssetsTextBox.Size = new System.Drawing.Size(200, 22);
            this.idFixedAssetsTextBox.TabIndex = 3;
            // 
            // designationFixedAssetsTextBox
            // 
            this.designationFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "DesignationFixedAssets", true));
            this.designationFixedAssetsTextBox.Location = new System.Drawing.Point(279, 82);
            this.designationFixedAssetsTextBox.Name = "designationFixedAssetsTextBox";
            this.designationFixedAssetsTextBox.Size = new System.Drawing.Size(200, 22);
            this.designationFixedAssetsTextBox.TabIndex = 5;
            // 
            // mAC_FATextBox
            // 
            this.mAC_FATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "MAC_FA", true));
            this.mAC_FATextBox.Location = new System.Drawing.Point(279, 110);
            this.mAC_FATextBox.Name = "mAC_FATextBox";
            this.mAC_FATextBox.Size = new System.Drawing.Size(200, 22);
            this.mAC_FATextBox.TabIndex = 7;
            // 
            // idMateriallyResponsiblePersonTextBox
            // 
            this.idMateriallyResponsiblePersonTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "idMateriallyResponsiblePerson", true));
            this.idMateriallyResponsiblePersonTextBox.Location = new System.Drawing.Point(279, 138);
            this.idMateriallyResponsiblePersonTextBox.Name = "idMateriallyResponsiblePersonTextBox";
            this.idMateriallyResponsiblePersonTextBox.Size = new System.Drawing.Size(200, 22);
            this.idMateriallyResponsiblePersonTextBox.TabIndex = 9;
            // 
            // surnameTextBox
            // 
            this.surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "Surname", true));
            this.surnameTextBox.Location = new System.Drawing.Point(279, 166);
            this.surnameTextBox.Name = "surnameTextBox";
            this.surnameTextBox.Size = new System.Drawing.Size(200, 22);
            this.surnameTextBox.TabIndex = 11;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(279, 194);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(200, 22);
            this.nameTextBox.TabIndex = 13;
            // 
            // patronimicTextBox
            // 
            this.patronimicTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.inflows_viewBindingSource, "Patronimic", true));
            this.patronimicTextBox.Location = new System.Drawing.Point(653, 22);
            this.patronimicTextBox.Name = "patronimicTextBox";
            this.patronimicTextBox.Size = new System.Drawing.Size(200, 22);
            this.patronimicTextBox.TabIndex = 15;
            // 
            // deliveryDateDateTimePicker
            // 
            this.deliveryDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.inflows_viewBindingSource, "DeliveryDate", true));
            this.deliveryDateDateTimePicker.Location = new System.Drawing.Point(653, 52);
            this.deliveryDateDateTimePicker.Name = "deliveryDateDateTimePicker";
            this.deliveryDateDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.deliveryDateDateTimePicker.TabIndex = 17;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(670, 493);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 40);
            this.button1.TabIndex = 9;
            this.button1.Text = "Загрузить все данные";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // inflows_viewTableAdapter
            // 
            this.inflows_viewTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Inflows_viewTableAdapter = this.inflows_viewTableAdapter;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.Inflows_viewTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // inflows_viewBindingNavigator
            // 
            this.inflows_viewBindingNavigator.AddNewItem = null;
            this.inflows_viewBindingNavigator.BindingSource = this.inflows_viewBindingSource;
            this.inflows_viewBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.inflows_viewBindingNavigator.DeleteItem = null;
            this.inflows_viewBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.inflows_viewBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.inflows_viewBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.inflows_viewBindingNavigator.Location = new System.Drawing.Point(0, 549);
            this.inflows_viewBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.inflows_viewBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.inflows_viewBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.inflows_viewBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.inflows_viewBindingNavigator.Name = "inflows_viewBindingNavigator";
            this.inflows_viewBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.inflows_viewBindingNavigator.Size = new System.Drawing.Size(894, 27);
            this.inflows_viewBindingNavigator.TabIndex = 10;
            this.inflows_viewBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // inflows_viewDataGridView
            // 
            this.inflows_viewDataGridView.AutoGenerateColumns = false;
            this.inflows_viewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.inflows_viewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.inflows_viewDataGridView.DataSource = this.inflows_viewBindingSource;
            this.inflows_viewDataGridView.Location = new System.Drawing.Point(13, 344);
            this.inflows_viewDataGridView.Name = "inflows_viewDataGridView";
            this.inflows_viewDataGridView.RowHeadersWidth = 51;
            this.inflows_viewDataGridView.RowTemplate.Height = 24;
            this.inflows_viewDataGridView.Size = new System.Drawing.Size(870, 142);
            this.inflows_viewDataGridView.TabIndex = 10;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idInflows";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код прихода";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "idFixedAssets";
            this.dataGridViewTextBoxColumn2.HeaderText = "Код ОС";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DesignationFixedAssets";
            this.dataGridViewTextBoxColumn3.HeaderText = "Наименование ОС";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MAC_FA";
            this.dataGridViewTextBoxColumn4.HeaderText = "Инвентарный номер ОС";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "idMateriallyResponsiblePerson";
            this.dataGridViewTextBoxColumn5.HeaderText = "Код МОЛ";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn6.HeaderText = "Фамилия МОЛ";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn7.HeaderText = "Имя МОЛ";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Patronimic";
            this.dataGridViewTextBoxColumn8.HeaderText = "Отчество МОЛ";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "DeliveryDate";
            this.dataGridViewTextBoxColumn9.HeaderText = "Дата поступления ОС";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // Inflows_view
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 576);
            this.Controls.Add(this.inflows_viewDataGridView);
            this.Controls.Add(this.inflows_viewBindingNavigator);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Inflows_view";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Приход";
            this.Load += new System.EventHandler(this.Inflows_view_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_view1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_viewBindingNavigator)).EndInit();
            this.inflows_viewBindingNavigator.ResumeLayout(false);
            this.inflows_viewBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inflows_viewDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private Dataset.Inflows_view inflows_view1;
        private System.Windows.Forms.BindingSource inflows_viewBindingSource;
        private Dataset.Inflows_viewTableAdapters.Inflows_viewTableAdapter inflows_viewTableAdapter;
        private Dataset.Inflows_viewTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator inflows_viewBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.TextBox idInflowsTextBox;
        private System.Windows.Forms.TextBox idFixedAssetsTextBox;
        private System.Windows.Forms.TextBox designationFixedAssetsTextBox;
        private System.Windows.Forms.TextBox mAC_FATextBox;
        private System.Windows.Forms.TextBox idMateriallyResponsiblePersonTextBox;
        private System.Windows.Forms.TextBox surnameTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox patronimicTextBox;
        private System.Windows.Forms.DateTimePicker deliveryDateDateTimePicker;
        private System.Windows.Forms.DataGridView inflows_viewDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}
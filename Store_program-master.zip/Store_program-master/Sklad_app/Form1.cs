﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bal_view Fbalance_1Table = new Bal_view();

            Fbalance_1Table.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MOL FMOL = new MOL();

            FMOL.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sklad_app.sixth_form.sixth_form_main FFixed = new sixth_form.sixth_form_main();

            FFixed.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Inflows_view Finflows_View = new Inflows_view();
            Finflows_View.Show();

           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Sklad_app.fifth_form.fifth_form_main Ffifth_form_main = new fifth_form.fifth_form_main();

            Ffifth_form_main.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Период o = new Период();
            o.stat = 1;
            o.Show();
            //Период o = new Период();
            //o.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Report o = new Report();
            o.stat = 2;
            o.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Report3 o = new Report3();
            o.stat = 3;
            o.Show();
        }

        private void расходДрагметалловНаСкладеToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Bal_view Fbalance_1Table = new Bal_view();

            Fbalance_1Table.Show();
        }

        private void приходОсновныхСредствНаСкладToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inflows_view Finflows_View = new Inflows_view();
            Finflows_View.Show();
        }

        private void основныеСредстваНаСкладеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sklad_app.sixth_form.sixth_form_main FFixed = new sixth_form.sixth_form_main();

            FFixed.Show();
        }

        private void журналУчетаДрагметалловНаСкладеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sklad_app.fifth_form.fifth_form_main Ffifth_form_main = new fifth_form.fifth_form_main();

            Ffifth_form_main.Show();
        }

        private void отчетОбОстаткахНаОтчетнуюДатуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Период o = new Период();
            o.stat = 1;
            o.Show();
        }

        private void описьОПередачеДрагметалловВЛабораториюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report o = new Report();
            o.stat = 2;
            o.Show();
        }

        private void журналУчетаПередачиДрагметалловНаСкладеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report3 o = new Report3();
            o.stat = 3;
            o.Show();
        }

        private void сменаПароляАдминистратораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Смена_пароля_админа смена = new Смена_пароля_админа();
            смена.Show();

        }
    }
}

﻿namespace Sklad_app
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.WorkTime_skDataSet1 = new Sklad_app.WorkTime_skDataSet1();
            this.Bal_view_sumBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Bal_view_sumTableAdapter = new Sklad_app.WorkTime_skDataSet1TableAdapters.Bal_view_sumTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.WorkTime_skDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bal_view_sumBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Bal_view_sumBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Sklad_app.Report2.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 34);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(891, 412);
            this.reportViewer1.TabIndex = 0;
            // 
            // WorkTime_skDataSet1
            // 
            this.WorkTime_skDataSet1.DataSetName = "WorkTime_skDataSet1";
            this.WorkTime_skDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Bal_view_sumBindingSource
            // 
            this.Bal_view_sumBindingSource.DataMember = "Bal_view_sum";
            this.Bal_view_sumBindingSource.DataSource = this.WorkTime_skDataSet1;
            // 
            // Bal_view_sumTableAdapter
            // 
            this.Bal_view_sumTableAdapter.ClearBeforeFill = true;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 485);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Report";
            this.Text = "Report";
            this.Load += new System.EventHandler(this.Report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.WorkTime_skDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bal_view_sumBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource Bal_view_sumBindingSource;
        private WorkTime_skDataSet1 WorkTime_skDataSet1;
        private WorkTime_skDataSet1TableAdapters.Bal_view_sumTableAdapter Bal_view_sumTableAdapter;
    }
}
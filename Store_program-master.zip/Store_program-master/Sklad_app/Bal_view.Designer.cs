﻿
namespace Sklad_app
{
    partial class Bal_view
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idBalanceLabel;
            System.Windows.Forms.Label idPreciousMetalsLabel;
            System.Windows.Forms.Label idFixedAssetsLabel;
            System.Windows.Forms.Label designationFixedAssetsLabel;
            System.Windows.Forms.Label designationLabel;
            System.Windows.Forms.Label quantityLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bal_view));
            this.panel1 = new System.Windows.Forms.Panel();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.Add_butt = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.bal_view1 = new Sklad_app.Dataset.Bal_view();
            this.bal_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bal_viewTableAdapter = new Sklad_app.Dataset.Bal_viewTableAdapters.Bal_viewTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.Bal_viewTableAdapters.TableAdapterManager();
            this.bal_viewBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bal_viewDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idBalanceTextBox = new System.Windows.Forms.TextBox();
            this.idPreciousMetalsTextBox = new System.Windows.Forms.TextBox();
            this.idFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.designationFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.designationTextBox = new System.Windows.Forms.TextBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            idBalanceLabel = new System.Windows.Forms.Label();
            idPreciousMetalsLabel = new System.Windows.Forms.Label();
            idFixedAssetsLabel = new System.Windows.Forms.Label();
            designationFixedAssetsLabel = new System.Windows.Forms.Label();
            designationLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bal_view1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bal_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bal_viewBindingNavigator)).BeginInit();
            this.bal_viewBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bal_viewDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // idBalanceLabel
            // 
            idBalanceLabel.AutoSize = true;
            idBalanceLabel.Location = new System.Drawing.Point(146, 54);
            idBalanceLabel.Name = "idBalanceLabel";
            idBalanceLabel.Size = new System.Drawing.Size(94, 17);
            idBalanceLabel.TabIndex = 0;
            idBalanceLabel.Text = "Код расхода:";
            // 
            // idPreciousMetalsLabel
            // 
            idPreciousMetalsLabel.AutoSize = true;
            idPreciousMetalsLabel.Location = new System.Drawing.Point(146, 82);
            idPreciousMetalsLabel.Name = "idPreciousMetalsLabel";
            idPreciousMetalsLabel.Size = new System.Drawing.Size(133, 17);
            idPreciousMetalsLabel.TabIndex = 2;
            idPreciousMetalsLabel.Text = "Код драгметаллов:";
            // 
            // idFixedAssetsLabel
            // 
            idFixedAssetsLabel.AutoSize = true;
            idFixedAssetsLabel.Location = new System.Drawing.Point(146, 110);
            idFixedAssetsLabel.Name = "idFixedAssetsLabel";
            idFixedAssetsLabel.Size = new System.Drawing.Size(159, 17);
            idFixedAssetsLabel.TabIndex = 4;
            idFixedAssetsLabel.Text = "Код основных средств:";
            // 
            // designationFixedAssetsLabel
            // 
            designationFixedAssetsLabel.AutoSize = true;
            designationFixedAssetsLabel.Location = new System.Drawing.Point(146, 138);
            designationFixedAssetsLabel.Name = "designationFixedAssetsLabel";
            designationFixedAssetsLabel.Size = new System.Drawing.Size(232, 17);
            designationFixedAssetsLabel.TabIndex = 6;
            designationFixedAssetsLabel.Text = "Наименование основных средств:";
            // 
            // designationLabel
            // 
            designationLabel.AutoSize = true;
            designationLabel.Location = new System.Drawing.Point(146, 166);
            designationLabel.Name = "designationLabel";
            designationLabel.Size = new System.Drawing.Size(206, 17);
            designationLabel.TabIndex = 8;
            designationLabel.Text = "Наименование драгметаллов:";
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(146, 194);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(186, 17);
            quantityLabel.TabIndex = 10;
            quantityLabel.Text = "Количество драгметаллов:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Controls.Add(this.Del_butt);
            this.panel1.Controls.Add(this.Edit_butt);
            this.panel1.Controls.Add(this.Add_butt);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(854, 87);
            this.panel1.TabIndex = 8;
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(594, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(455, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(329, 4);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 2;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            this.Del_butt.Click += new System.EventHandler(this.Del_butt_Click);
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(160, 4);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 1;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            this.Edit_butt.Click += new System.EventHandler(this.Edit_butt_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(16, 4);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(134, 71);
            this.Add_butt.TabIndex = 0;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            this.Add_butt.Click += new System.EventHandler(this.Add_butt_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(670, 626);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 40);
            this.button1.TabIndex = 10;
            this.button1.Text = "Загрузить все данные";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bal_view1
            // 
            this.bal_view1.DataSetName = "Bal_view";
            this.bal_view1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bal_viewBindingSource
            // 
            this.bal_viewBindingSource.DataMember = "Bal_view";
            this.bal_viewBindingSource.DataSource = this.bal_view1;
            // 
            // bal_viewTableAdapter
            // 
            this.bal_viewTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Bal_viewTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.Bal_viewTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // bal_viewBindingNavigator
            // 
            this.bal_viewBindingNavigator.AddNewItem = null;
            this.bal_viewBindingNavigator.BindingSource = this.bal_viewBindingSource;
            this.bal_viewBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.bal_viewBindingNavigator.DeleteItem = null;
            this.bal_viewBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bal_viewBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bal_viewBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.bal_viewBindingNavigator.Location = new System.Drawing.Point(0, 686);
            this.bal_viewBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bal_viewBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bal_viewBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bal_viewBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bal_viewBindingNavigator.Name = "bal_viewBindingNavigator";
            this.bal_viewBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.bal_viewBindingNavigator.Size = new System.Drawing.Size(890, 27);
            this.bal_viewBindingNavigator.TabIndex = 11;
            this.bal_viewBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // bal_viewDataGridView
            // 
            this.bal_viewDataGridView.AutoGenerateColumns = false;
            this.bal_viewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bal_viewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.bal_viewDataGridView.DataSource = this.bal_viewBindingSource;
            this.bal_viewDataGridView.Location = new System.Drawing.Point(44, 372);
            this.bal_viewDataGridView.Name = "bal_viewDataGridView";
            this.bal_viewDataGridView.RowHeadersWidth = 51;
            this.bal_viewDataGridView.RowTemplate.Height = 24;
            this.bal_viewDataGridView.Size = new System.Drawing.Size(823, 220);
            this.bal_viewDataGridView.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(idBalanceLabel);
            this.groupBox1.Controls.Add(this.idBalanceTextBox);
            this.groupBox1.Controls.Add(idPreciousMetalsLabel);
            this.groupBox1.Controls.Add(this.idPreciousMetalsTextBox);
            this.groupBox1.Controls.Add(idFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.idFixedAssetsTextBox);
            this.groupBox1.Controls.Add(designationFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.designationFixedAssetsTextBox);
            this.groupBox1.Controls.Add(designationLabel);
            this.groupBox1.Controls.Add(this.designationTextBox);
            this.groupBox1.Controls.Add(quantityLabel);
            this.groupBox1.Controls.Add(this.quantityTextBox);
            this.groupBox1.Location = new System.Drawing.Point(13, 108);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(854, 236);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация";
            // 
            // idBalanceTextBox
            // 
            this.idBalanceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bal_viewBindingSource, "idBalance", true));
            this.idBalanceTextBox.Location = new System.Drawing.Point(486, 54);
            this.idBalanceTextBox.Name = "idBalanceTextBox";
            this.idBalanceTextBox.Size = new System.Drawing.Size(100, 22);
            this.idBalanceTextBox.TabIndex = 1;
            // 
            // idPreciousMetalsTextBox
            // 
            this.idPreciousMetalsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bal_viewBindingSource, "idPreciousMetals", true));
            this.idPreciousMetalsTextBox.Location = new System.Drawing.Point(486, 82);
            this.idPreciousMetalsTextBox.Name = "idPreciousMetalsTextBox";
            this.idPreciousMetalsTextBox.Size = new System.Drawing.Size(100, 22);
            this.idPreciousMetalsTextBox.TabIndex = 3;
            // 
            // idFixedAssetsTextBox
            // 
            this.idFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bal_viewBindingSource, "idFixedAssets", true));
            this.idFixedAssetsTextBox.Location = new System.Drawing.Point(486, 110);
            this.idFixedAssetsTextBox.Name = "idFixedAssetsTextBox";
            this.idFixedAssetsTextBox.Size = new System.Drawing.Size(100, 22);
            this.idFixedAssetsTextBox.TabIndex = 5;
            // 
            // designationFixedAssetsTextBox
            // 
            this.designationFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bal_viewBindingSource, "DesignationFixedAssets", true));
            this.designationFixedAssetsTextBox.Location = new System.Drawing.Point(486, 138);
            this.designationFixedAssetsTextBox.Name = "designationFixedAssetsTextBox";
            this.designationFixedAssetsTextBox.Size = new System.Drawing.Size(100, 22);
            this.designationFixedAssetsTextBox.TabIndex = 7;
            // 
            // designationTextBox
            // 
            this.designationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bal_viewBindingSource, "Designation", true));
            this.designationTextBox.Location = new System.Drawing.Point(486, 166);
            this.designationTextBox.Name = "designationTextBox";
            this.designationTextBox.Size = new System.Drawing.Size(100, 22);
            this.designationTextBox.TabIndex = 9;
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bal_viewBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(486, 194);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(100, 22);
            this.quantityTextBox.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idBalance";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код расхода";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "idPreciousMetals";
            this.dataGridViewTextBoxColumn2.HeaderText = "Код драгметаллов";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "idFixedAssets";
            this.dataGridViewTextBoxColumn3.HeaderText = "Код ОС";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DesignationFixedAssets";
            this.dataGridViewTextBoxColumn4.HeaderText = "Наименование ОС";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Designation";
            this.dataGridViewTextBoxColumn5.HeaderText = "Наименование драгметаллов";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn6.HeaderText = "Количество драгметаллов";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // Bal_view
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 713);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bal_viewDataGridView);
            this.Controls.Add(this.bal_viewBindingNavigator);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Name = "Bal_view";
            this.Text = "Расход драгметаллов на складе";
            this.Load += new System.EventHandler(this.Bal_view_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bal_view1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bal_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bal_viewBindingNavigator)).EndInit();
            this.bal_viewBindingNavigator.ResumeLayout(false);
            this.bal_viewBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bal_viewDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.Button button1;
        private Dataset.Bal_view bal_view1;
        private System.Windows.Forms.BindingSource bal_viewBindingSource;
        private Dataset.Bal_viewTableAdapters.Bal_viewTableAdapter bal_viewTableAdapter;
        private Dataset.Bal_viewTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator bal_viewBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView bal_viewDataGridView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox idBalanceTextBox;
        private System.Windows.Forms.TextBox idPreciousMetalsTextBox;
        private System.Windows.Forms.TextBox idFixedAssetsTextBox;
        private System.Windows.Forms.TextBox designationFixedAssetsTextBox;
        private System.Windows.Forms.TextBox designationTextBox;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}
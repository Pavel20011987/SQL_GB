﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.sixth_form
{
    public partial class sixth_form_main : Form
    {
        public sixth_form_main()
        {
            InitializeComponent();
        }

        private void fixedBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.fixedBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._fixed);

        }

        private void sixth_form_main_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_fixed._Fixed". При необходимости она может быть перемещена или удалена.
            //this.fixedTableAdapter.Fill(this._fixed._Fixed);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.fixedTableAdapter.Fill(this._fixed._Fixed);
        }

        private void Add_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.sixth_form.sixth_form_child frm = new sixth_form_child();
            frm.st_lb.Text = "Новое значение";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.fixedTableAdapter.Fill(this._fixed._Fixed);
            }

            //-----------------------------------------
        }

        private void Edit_butt_Click(object sender, EventArgs e)
        {
            Int32 rn;
            rn = this._fixed._Fixed.Rows.Count;
            if (rn == 0)
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования!");
                return;
            }
            Sklad_app.sixth_form.sixth_form_child frm = new sixth_form_child();
            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idFixedAssetsLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.st_lb.Text = "Значение для редактирования";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.fixedTableAdapter.Fill(this._fixed._Fixed);
            }

            //-----------------------------------------
        }

        private void Del_butt_Click(object sender, EventArgs e)
        {
            Sklad_app.sixth_form.sixth_form_child frm = new sixth_form_child();

            //-------------------------------------------------------------------
            Int32 i;
            Int32.TryParse(this.idFixedAssetsLabel1.Text, out i);
            frm.Sel_id_lb.Text = i.ToString();
            //--------------------------------------------------------------------
            frm.Sel_id_lb.Text = this.idFixedAssetsLabel1.Text;
            frm.st_lb.Text = "Значение для удаления";
            frm.ShowDialog();
            frm.Dispose();
            //-----------------------------------------
            if (frm.DialogResult == DialogResult.OK)
            {
                this.fixedTableAdapter.Fill(this._fixed._Fixed);
            }

            //-----------------------------------------
        }
    }
}

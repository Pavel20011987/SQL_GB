﻿
namespace Sklad_app.sixth_form
{
    partial class sixth_form_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idFixedAssetsLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sixth_form_main));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.Add_butt = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this._fixed = new Sklad_app.Dataset.Fixed();
            this.fixedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fixedTableAdapter = new Sklad_app.Dataset.FixedTableAdapters.FixedTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.FixedTableAdapters.TableAdapterManager();
            this.fixedBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.fixedDataGridView = new System.Windows.Forms.DataGridView();
            this.idFixedAssetsLabel1 = new System.Windows.Forms.Label();
            this.idFixedAssetsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designationFixedAssetsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mACFADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patronimicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDesignationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            idFixedAssetsLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._fixed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingNavigator)).BeginInit();
            this.fixedBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fixedDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idFixedAssetsLabel
            // 
            idFixedAssetsLabel.AutoSize = true;
            idFixedAssetsLabel.Location = new System.Drawing.Point(785, 259);
            idFixedAssetsLabel.Name = "idFixedAssetsLabel";
            idFixedAssetsLabel.Size = new System.Drawing.Size(106, 17);
            idFixedAssetsLabel.TabIndex = 12;
            idFixedAssetsLabel.Text = "id Fixed Assets:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Del_butt);
            this.panel1.Controls.Add(this.Edit_butt);
            this.panel1.Controls.Add(this.Add_butt);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(701, 87);
            this.panel1.TabIndex = 9;
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(329, 4);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 2;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            this.Del_butt.Click += new System.EventHandler(this.Del_butt_Click);
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(158, 4);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 1;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            this.Edit_butt.Click += new System.EventHandler(this.Edit_butt_Click);
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(16, 4);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(134, 71);
            this.Add_butt.TabIndex = 0;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            this.Add_butt.Click += new System.EventHandler(this.Add_butt_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(517, 452);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 40);
            this.button1.TabIndex = 11;
            this.button1.Text = "Загрузить все данные";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // _fixed
            // 
            this._fixed.DataSetName = "Fixed";
            this._fixed.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fixedBindingSource
            // 
            this.fixedBindingSource.DataMember = "Fixed";
            this.fixedBindingSource.DataSource = this._fixed;
            // 
            // fixedTableAdapter
            // 
            this.fixedTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FixedTableAdapter = this.fixedTableAdapter;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.FixedTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // fixedBindingNavigator
            // 
            this.fixedBindingNavigator.AddNewItem = null;
            this.fixedBindingNavigator.BindingSource = this.fixedBindingSource;
            this.fixedBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.fixedBindingNavigator.DeleteItem = null;
            this.fixedBindingNavigator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fixedBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fixedBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.fixedBindingNavigator.Location = new System.Drawing.Point(0, 530);
            this.fixedBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.fixedBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.fixedBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.fixedBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.fixedBindingNavigator.Name = "fixedBindingNavigator";
            this.fixedBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.fixedBindingNavigator.Size = new System.Drawing.Size(737, 27);
            this.fixedBindingNavigator.TabIndex = 12;
            this.fixedBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // fixedDataGridView
            // 
            this.fixedDataGridView.AutoGenerateColumns = false;
            this.fixedDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fixedDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idFixedAssetsDataGridViewTextBoxColumn,
            this.designationFixedAssetsDataGridViewTextBoxColumn,
            this.mACFADataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.patronimicDataGridViewTextBoxColumn,
            this.designationDataGridViewTextBoxColumn,
            this.quantityDesignationDataGridViewTextBoxColumn,
            this.Column1});
            this.fixedDataGridView.DataSource = this.fixedBindingSource;
            this.fixedDataGridView.Location = new System.Drawing.Point(13, 158);
            this.fixedDataGridView.Name = "fixedDataGridView";
            this.fixedDataGridView.RowHeadersWidth = 51;
            this.fixedDataGridView.RowTemplate.Height = 24;
            this.fixedDataGridView.Size = new System.Drawing.Size(701, 276);
            this.fixedDataGridView.TabIndex = 12;
            // 
            // idFixedAssetsLabel1
            // 
            this.idFixedAssetsLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "idFixedAssets", true));
            this.idFixedAssetsLabel1.Location = new System.Drawing.Point(897, 259);
            this.idFixedAssetsLabel1.Name = "idFixedAssetsLabel1";
            this.idFixedAssetsLabel1.Size = new System.Drawing.Size(100, 23);
            this.idFixedAssetsLabel1.TabIndex = 13;
            this.idFixedAssetsLabel1.Text = "label1";
            // 
            // idFixedAssetsDataGridViewTextBoxColumn
            // 
            this.idFixedAssetsDataGridViewTextBoxColumn.DataPropertyName = "idFixedAssets";
            this.idFixedAssetsDataGridViewTextBoxColumn.HeaderText = "Код ОС";
            this.idFixedAssetsDataGridViewTextBoxColumn.Name = "idFixedAssetsDataGridViewTextBoxColumn";
            this.idFixedAssetsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // designationFixedAssetsDataGridViewTextBoxColumn
            // 
            this.designationFixedAssetsDataGridViewTextBoxColumn.DataPropertyName = "DesignationFixedAssets";
            this.designationFixedAssetsDataGridViewTextBoxColumn.HeaderText = "Наименование ОС";
            this.designationFixedAssetsDataGridViewTextBoxColumn.Name = "designationFixedAssetsDataGridViewTextBoxColumn";
            // 
            // mACFADataGridViewTextBoxColumn
            // 
            this.mACFADataGridViewTextBoxColumn.DataPropertyName = "MAC_FA";
            this.mACFADataGridViewTextBoxColumn.HeaderText = "Инвентарный номер ОС";
            this.mACFADataGridViewTextBoxColumn.Name = "mACFADataGridViewTextBoxColumn";
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия МОЛ";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Имя МОЛ";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // patronimicDataGridViewTextBoxColumn
            // 
            this.patronimicDataGridViewTextBoxColumn.DataPropertyName = "Patronimic";
            this.patronimicDataGridViewTextBoxColumn.HeaderText = "Отчество МОЛ";
            this.patronimicDataGridViewTextBoxColumn.Name = "patronimicDataGridViewTextBoxColumn";
            // 
            // designationDataGridViewTextBoxColumn
            // 
            this.designationDataGridViewTextBoxColumn.DataPropertyName = "Designation";
            this.designationDataGridViewTextBoxColumn.HeaderText = "Наименование драгметаллов";
            this.designationDataGridViewTextBoxColumn.Name = "designationDataGridViewTextBoxColumn";
            // 
            // quantityDesignationDataGridViewTextBoxColumn
            // 
            this.quantityDesignationDataGridViewTextBoxColumn.DataPropertyName = "QuantityDesignation";
            this.quantityDesignationDataGridViewTextBoxColumn.HeaderText = "Количество драгметаллов";
            this.quantityDesignationDataGridViewTextBoxColumn.Name = "quantityDesignationDataGridViewTextBoxColumn";
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "DeliveryDate";
            this.Column1.HeaderText = "Дата прихода";
            this.Column1.Name = "Column1";
            // 
            // sixth_form_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(737, 557);
            this.Controls.Add(idFixedAssetsLabel);
            this.Controls.Add(this.idFixedAssetsLabel1);
            this.Controls.Add(this.fixedDataGridView);
            this.Controls.Add(this.fixedBindingNavigator);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Name = "sixth_form_main";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Основные средства";
            this.Load += new System.EventHandler(this.sixth_form_main_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._fixed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingNavigator)).EndInit();
            this.fixedBindingNavigator.ResumeLayout(false);
            this.fixedBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fixedDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.Button button1;
        private Dataset.Fixed _fixed;
        private System.Windows.Forms.BindingSource fixedBindingSource;
        private Dataset.FixedTableAdapters.FixedTableAdapter fixedTableAdapter;
        private Dataset.FixedTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator fixedBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView fixedDataGridView;
        private System.Windows.Forms.Label idFixedAssetsLabel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idFixedAssetsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn designationFixedAssetsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mACFADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn patronimicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn designationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDesignationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    }
}
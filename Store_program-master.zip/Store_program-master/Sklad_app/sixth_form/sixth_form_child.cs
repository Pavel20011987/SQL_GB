﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad_app.sixth_form
{
    public partial class sixth_form_child : Form
    {
        public sixth_form_child()
        {
            InitializeComponent();
        }

        private void fixedBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.fixedBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._fixed);

        }

        private void sixth_form_child_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_fixed._Fixed". При необходимости она может быть перемещена или удалена.
            // this.fixedTableAdapter.Fill(this._fixed._Fixed);
            if (this.st_lb.Text == "Новое значение")
            {
                this.fixedBindingSource.AddNew();
                this.groupBox1.Enabled = true;
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для редактирования")
            {
                this.groupBox1.Enabled = true;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.fixedTableAdapter.FillBy(this._fixed._Fixed, (int)i);
                //------------------------------------------------
            }
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.groupBox1.Enabled = false;
                //------------------------------------------------
                Int64 i;
                Int64.TryParse(this.Sel_id_lb.Text, out i);
                this.fixedTableAdapter.FillBy(this._fixed._Fixed, (int)i);
                //------------------------------------------------
            }

        }

        private void save_butt_Click(object sender, EventArgs e)
        {
            //------------------------------------------
            if (this.st_lb.Text == "Значение для удаления")
            {
                this.fixedBindingSource.RemoveCurrent();
            }

            this.Validate();
            this.fixedBindingSource.EndEdit();
            // this.dataTable1BindingSource1.EndEdit();
            Int32 r;
            r = this.fixedTableAdapter.Update(this._fixed._Fixed);
            if (r > 0)
            {
                MessageBox.Show("Сохранено! Счетчик: " + r.ToString());
                // this.Close();
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Ничего не сохранилось! ");
            }
        }

        private void cancel_butt_Click(object sender, EventArgs e)
        {
            // this.Close();
            this.DialogResult = DialogResult.Cancel;
        }

        private void deliveryDateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}

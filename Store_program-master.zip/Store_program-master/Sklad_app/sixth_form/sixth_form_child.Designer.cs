﻿
namespace Sklad_app.sixth_form
{
    partial class sixth_form_child
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label idFixedAssetsLabel;
            System.Windows.Forms.Label designationFixedAssetsLabel;
            System.Windows.Forms.Label mAC_FALabel;
            System.Windows.Forms.Label surnameLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label patronimicLabel;
            System.Windows.Forms.Label designationLabel;
            System.Windows.Forms.Label quantityDesignationLabel;
            System.Windows.Forms.Label deliveryDateLabel;
            this.panel1 = new System.Windows.Forms.Panel();
            this.cancel_butt = new System.Windows.Forms.Button();
            this.save_butt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.fixedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._fixed = new Sklad_app.Dataset.Fixed();
            this.designationFixedAssetsTextBox = new System.Windows.Forms.TextBox();
            this.mAC_FATextBox = new System.Windows.Forms.TextBox();
            this.surnameTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.patronimicTextBox = new System.Windows.Forms.TextBox();
            this.designationTextBox = new System.Windows.Forms.TextBox();
            this.quantityDesignationTextBox = new System.Windows.Forms.TextBox();
            this.Add_butt = new System.Windows.Forms.Button();
            this.Del_butt = new System.Windows.Forms.Button();
            this.Edit_butt = new System.Windows.Forms.Button();
            this.Sel_id_lb = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.st_lb = new System.Windows.Forms.Label();
            this.fixedTableAdapter = new Sklad_app.Dataset.FixedTableAdapters.FixedTableAdapter();
            this.tableAdapterManager = new Sklad_app.Dataset.FixedTableAdapters.TableAdapterManager();
            this.deliveryDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            label1 = new System.Windows.Forms.Label();
            idFixedAssetsLabel = new System.Windows.Forms.Label();
            designationFixedAssetsLabel = new System.Windows.Forms.Label();
            mAC_FALabel = new System.Windows.Forms.Label();
            surnameLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            patronimicLabel = new System.Windows.Forms.Label();
            designationLabel = new System.Windows.Forms.Label();
            quantityDesignationLabel = new System.Windows.Forms.Label();
            deliveryDateLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._fixed)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label1.Location = new System.Drawing.Point(15, 16);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(73, 20);
            label1.TabIndex = 3;
            label1.Text = "Статус:";
            // 
            // idFixedAssetsLabel
            // 
            idFixedAssetsLabel.AutoSize = true;
            idFixedAssetsLabel.Location = new System.Drawing.Point(75, 29);
            idFixedAssetsLabel.Name = "idFixedAssetsLabel";
            idFixedAssetsLabel.Size = new System.Drawing.Size(61, 17);
            idFixedAssetsLabel.TabIndex = 0;
            idFixedAssetsLabel.Text = "Код ОС:";
            // 
            // designationFixedAssetsLabel
            // 
            designationFixedAssetsLabel.AutoSize = true;
            designationFixedAssetsLabel.Location = new System.Drawing.Point(75, 57);
            designationFixedAssetsLabel.Name = "designationFixedAssetsLabel";
            designationFixedAssetsLabel.Size = new System.Drawing.Size(134, 17);
            designationFixedAssetsLabel.TabIndex = 2;
            designationFixedAssetsLabel.Text = "Наименование ОС:";
            // 
            // mAC_FALabel
            // 
            mAC_FALabel.AutoSize = true;
            mAC_FALabel.Location = new System.Drawing.Point(75, 85);
            mAC_FALabel.Name = "mAC_FALabel";
            mAC_FALabel.Size = new System.Drawing.Size(171, 17);
            mAC_FALabel.TabIndex = 4;
            mAC_FALabel.Text = "Инвентарный номер ОС:";
            // 
            // surnameLabel
            // 
            surnameLabel.AutoSize = true;
            surnameLabel.Location = new System.Drawing.Point(75, 113);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new System.Drawing.Size(74, 17);
            surnameLabel.TabIndex = 6;
            surnameLabel.Text = "Фамилия:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(75, 141);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(39, 17);
            nameLabel.TabIndex = 8;
            nameLabel.Text = "Имя:";
            // 
            // patronimicLabel
            // 
            patronimicLabel.AutoSize = true;
            patronimicLabel.Location = new System.Drawing.Point(75, 169);
            patronimicLabel.Name = "patronimicLabel";
            patronimicLabel.Size = new System.Drawing.Size(75, 17);
            patronimicLabel.TabIndex = 10;
            patronimicLabel.Text = "Отчество:";
            // 
            // designationLabel
            // 
            designationLabel.AutoSize = true;
            designationLabel.Location = new System.Drawing.Point(75, 197);
            designationLabel.Name = "designationLabel";
            designationLabel.Size = new System.Drawing.Size(206, 17);
            designationLabel.TabIndex = 12;
            designationLabel.Text = "Наименование драгметаллов:";
            // 
            // quantityDesignationLabel
            // 
            quantityDesignationLabel.AutoSize = true;
            quantityDesignationLabel.Location = new System.Drawing.Point(75, 225);
            quantityDesignationLabel.Name = "quantityDesignationLabel";
            quantityDesignationLabel.Size = new System.Drawing.Size(186, 17);
            quantityDesignationLabel.TabIndex = 14;
            quantityDesignationLabel.Text = "Количество драгметаллов:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cancel_butt);
            this.panel1.Controls.Add(this.save_butt);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(492, 87);
            this.panel1.TabIndex = 14;
            // 
            // cancel_butt
            // 
            this.cancel_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancel_butt.Image = global::Sklad_app.Properties.Resources.cancel_button;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancel_butt.Location = new System.Drawing.Point(171, 4);
            this.cancel_butt.Margin = new System.Windows.Forms.Padding(4);
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(126, 71);
            this.cancel_butt.TabIndex = 4;
            this.cancel_butt.Text = "Отменить изменения";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancel_butt.UseVisualStyleBackColor = true;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // save_butt
            // 
            this.save_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_butt.Image = global::Sklad_app.Properties.Resources.save_button;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_butt.Location = new System.Drawing.Point(10, 4);
            this.save_butt.Margin = new System.Windows.Forms.Padding(4);
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(131, 71);
            this.save_butt.TabIndex = 3;
            this.save_butt.Text = "Сохранить";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.save_butt.UseVisualStyleBackColor = true;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(deliveryDateLabel);
            this.groupBox1.Controls.Add(this.deliveryDateDateTimePicker);
            this.groupBox1.Controls.Add(idFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.idFixedAssetsTextBox);
            this.groupBox1.Controls.Add(designationFixedAssetsLabel);
            this.groupBox1.Controls.Add(this.designationFixedAssetsTextBox);
            this.groupBox1.Controls.Add(mAC_FALabel);
            this.groupBox1.Controls.Add(this.mAC_FATextBox);
            this.groupBox1.Controls.Add(surnameLabel);
            this.groupBox1.Controls.Add(this.surnameTextBox);
            this.groupBox1.Controls.Add(nameLabel);
            this.groupBox1.Controls.Add(this.nameTextBox);
            this.groupBox1.Controls.Add(patronimicLabel);
            this.groupBox1.Controls.Add(this.patronimicTextBox);
            this.groupBox1.Controls.Add(designationLabel);
            this.groupBox1.Controls.Add(this.designationTextBox);
            this.groupBox1.Controls.Add(quantityDesignationLabel);
            this.groupBox1.Controls.Add(this.quantityDesignationTextBox);
            this.groupBox1.Location = new System.Drawing.Point(13, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(506, 322);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация";
            // 
            // idFixedAssetsTextBox
            // 
            this.idFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "idFixedAssets", true));
            this.idFixedAssetsTextBox.Location = new System.Drawing.Point(287, 29);
            this.idFixedAssetsTextBox.Name = "idFixedAssetsTextBox";
            this.idFixedAssetsTextBox.ReadOnly = true;
            this.idFixedAssetsTextBox.Size = new System.Drawing.Size(199, 22);
            this.idFixedAssetsTextBox.TabIndex = 1;
            // 
            // fixedBindingSource
            // 
            this.fixedBindingSource.DataMember = "Fixed";
            this.fixedBindingSource.DataSource = this._fixed;
            // 
            // _fixed
            // 
            this._fixed.DataSetName = "Fixed";
            this._fixed.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // designationFixedAssetsTextBox
            // 
            this.designationFixedAssetsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "DesignationFixedAssets", true));
            this.designationFixedAssetsTextBox.Location = new System.Drawing.Point(287, 57);
            this.designationFixedAssetsTextBox.Name = "designationFixedAssetsTextBox";
            this.designationFixedAssetsTextBox.Size = new System.Drawing.Size(199, 22);
            this.designationFixedAssetsTextBox.TabIndex = 3;
            // 
            // mAC_FATextBox
            // 
            this.mAC_FATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "MAC_FA", true));
            this.mAC_FATextBox.Location = new System.Drawing.Point(287, 85);
            this.mAC_FATextBox.Name = "mAC_FATextBox";
            this.mAC_FATextBox.Size = new System.Drawing.Size(199, 22);
            this.mAC_FATextBox.TabIndex = 5;
            // 
            // surnameTextBox
            // 
            this.surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "Surname", true));
            this.surnameTextBox.Location = new System.Drawing.Point(287, 113);
            this.surnameTextBox.Name = "surnameTextBox";
            this.surnameTextBox.Size = new System.Drawing.Size(199, 22);
            this.surnameTextBox.TabIndex = 7;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(287, 141);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(199, 22);
            this.nameTextBox.TabIndex = 9;
            // 
            // patronimicTextBox
            // 
            this.patronimicTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "Patronimic", true));
            this.patronimicTextBox.Location = new System.Drawing.Point(287, 169);
            this.patronimicTextBox.Name = "patronimicTextBox";
            this.patronimicTextBox.Size = new System.Drawing.Size(199, 22);
            this.patronimicTextBox.TabIndex = 11;
            // 
            // designationTextBox
            // 
            this.designationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "Designation", true));
            this.designationTextBox.Location = new System.Drawing.Point(287, 197);
            this.designationTextBox.Name = "designationTextBox";
            this.designationTextBox.Size = new System.Drawing.Size(199, 22);
            this.designationTextBox.TabIndex = 13;
            // 
            // quantityDesignationTextBox
            // 
            this.quantityDesignationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fixedBindingSource, "QuantityDesignation", true));
            this.quantityDesignationTextBox.Location = new System.Drawing.Point(287, 225);
            this.quantityDesignationTextBox.Name = "quantityDesignationTextBox";
            this.quantityDesignationTextBox.Size = new System.Drawing.Size(199, 22);
            this.quantityDesignationTextBox.TabIndex = 15;
            // 
            // Add_butt
            // 
            this.Add_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_butt.Image = global::Sklad_app.Properties.Resources.new_button;
            this.Add_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Add_butt.Location = new System.Drawing.Point(584, 210);
            this.Add_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Add_butt.Name = "Add_butt";
            this.Add_butt.Size = new System.Drawing.Size(109, 71);
            this.Add_butt.TabIndex = 22;
            this.Add_butt.Text = "Добавить ";
            this.Add_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Add_butt.UseVisualStyleBackColor = true;
            // 
            // Del_butt
            // 
            this.Del_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del_butt.Image = global::Sklad_app.Properties.Resources.del_button;
            this.Del_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Del_butt.Location = new System.Drawing.Point(872, 210);
            this.Del_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Del_butt.Name = "Del_butt";
            this.Del_butt.Size = new System.Drawing.Size(119, 71);
            this.Del_butt.TabIndex = 24;
            this.Del_butt.Text = "Удалить";
            this.Del_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Del_butt.UseVisualStyleBackColor = true;
            // 
            // Edit_butt
            // 
            this.Edit_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit_butt.Image = global::Sklad_app.Properties.Resources.edit_button;
            this.Edit_butt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Edit_butt.Location = new System.Drawing.Point(701, 210);
            this.Edit_butt.Margin = new System.Windows.Forms.Padding(4);
            this.Edit_butt.Name = "Edit_butt";
            this.Edit_butt.Size = new System.Drawing.Size(163, 71);
            this.Edit_butt.TabIndex = 23;
            this.Edit_butt.Text = "Редактировать";
            this.Edit_butt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Edit_butt.UseVisualStyleBackColor = true;
            // 
            // Sel_id_lb
            // 
            this.Sel_id_lb.AutoSize = true;
            this.Sel_id_lb.Location = new System.Drawing.Point(532, 222);
            this.Sel_id_lb.Name = "Sel_id_lb";
            this.Sel_id_lb.Size = new System.Drawing.Size(45, 17);
            this.Sel_id_lb.TabIndex = 21;
            this.Sel_id_lb.Text = "sel id:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.st_lb);
            this.panel2.Controls.Add(label1);
            this.panel2.Location = new System.Drawing.Point(24, 469);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(480, 71);
            this.panel2.TabIndex = 25;
            // 
            // st_lb
            // 
            this.st_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.st_lb.ForeColor = System.Drawing.Color.Maroon;
            this.st_lb.Location = new System.Drawing.Point(94, 16);
            this.st_lb.Name = "st_lb";
            this.st_lb.Size = new System.Drawing.Size(357, 20);
            this.st_lb.TabIndex = 4;
            this.st_lb.Text = "-";
            this.st_lb.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // fixedTableAdapter
            // 
            this.fixedTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FixedTableAdapter = this.fixedTableAdapter;
            this.tableAdapterManager.UpdateOrder = Sklad_app.Dataset.FixedTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // deliveryDateLabel
            // 
            deliveryDateLabel.AutoSize = true;
            deliveryDateLabel.Location = new System.Drawing.Point(75, 273);
            deliveryDateLabel.Name = "deliveryDateLabel";
            deliveryDateLabel.Size = new System.Drawing.Size(104, 17);
            deliveryDateLabel.TabIndex = 16;
            deliveryDateLabel.Text = "Дата прихода:";
            // 
            // deliveryDateDateTimePicker
            // 
            this.deliveryDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.fixedBindingSource, "DeliveryDate", true));
            this.deliveryDateDateTimePicker.Location = new System.Drawing.Point(286, 268);
            this.deliveryDateDateTimePicker.Name = "deliveryDateDateTimePicker";
            this.deliveryDateDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.deliveryDateDateTimePicker.TabIndex = 17;
            this.deliveryDateDateTimePicker.ValueChanged += new System.EventHandler(this.deliveryDateDateTimePicker_ValueChanged);
            // 
            // sixth_form_child
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(533, 569);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Add_butt);
            this.Controls.Add(this.Del_butt);
            this.Controls.Add(this.Edit_butt);
            this.Controls.Add(this.Sel_id_lb);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "sixth_form_child";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "sixth_form_child";
            this.Load += new System.EventHandler(this.sixth_form_child_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fixedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._fixed)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cancel_butt;
        private System.Windows.Forms.Button save_butt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Add_butt;
        private System.Windows.Forms.Button Del_butt;
        private System.Windows.Forms.Button Edit_butt;
        public System.Windows.Forms.Label Sel_id_lb;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label st_lb;
        private Dataset.Fixed _fixed;
        private System.Windows.Forms.BindingSource fixedBindingSource;
        private Dataset.FixedTableAdapters.FixedTableAdapter fixedTableAdapter;
        private Dataset.FixedTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox idFixedAssetsTextBox;
        private System.Windows.Forms.TextBox designationFixedAssetsTextBox;
        private System.Windows.Forms.TextBox mAC_FATextBox;
        private System.Windows.Forms.TextBox surnameTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox patronimicTextBox;
        private System.Windows.Forms.TextBox designationTextBox;
        private System.Windows.Forms.TextBox quantityDesignationTextBox;
        private System.Windows.Forms.DateTimePicker deliveryDateDateTimePicker;
    }
}